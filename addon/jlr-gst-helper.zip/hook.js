// JLR GST Helper — runs in the GST portal page itself (MAIN world).
// The portal makes its GSTR-1 / GSTR-3B PDFs in the browser with pdfMake. When it does, this keeps a copy and hands it to the
// add-on (content.js), which sends it to the tracker. The portal's own download still happens as usual. Nothing is changed on the portal.
(() => {
  if (window.__jlrHook) return; window.__jlrHook = true;
  const WANT = /^(GSTR1|IFF|GSTR3B)_[0-9A-Z]{15}_\d{6}\.pdf$/i;
  const texts = dd => { const out = []; const walk = x => { if (out.length > 400) return; if (typeof x === 'string' || typeof x === 'number') out.push(String(x)); else if (Array.isArray(x)) x.forEach(walk); else if (x && typeof x === 'object') { if ('text' in x) walk(x.text); ['content', 'table', 'body', 'stack', 'columns', 'ul', 'ol'].forEach(k => { if (x[k]) walk(x[k]); }); } }; try { walk(dd.content); } catch { /* ignore */ } return out.slice(0, 120); };
  const wm = dd => { const w = dd && dd.watermark; return typeof w === 'string' ? w : w && w.text ? String(w.text) : ''; };
  function wrapDoc(pm, dd, doc, args) {
    ['download', 'open', 'print'].forEach(fn => {
      const orig = doc[fn]; if (typeof orig !== 'function') return;
      doc[fn] = function (name, ...rest) {
        const nm = fn === 'download' && typeof name === 'string' ? name : '';
        if (WANT.test(nm)) {
          try { pm.__jlrOrig(dd, ...args).getBase64(b64 => window.postMessage({ __jlrpdf: 1, name: nm, b64, wm: wm(dd), texts: texts(dd) }, location.origin)); } catch { /* ignore */ }
        }
        return orig.call(this, name, ...rest);
      };
    });
    return doc;
  }
  function wrap(pm) {
    if (!pm || typeof pm !== 'object' || pm.__jlrOrig || typeof pm.createPdf !== 'function') return pm;
    const orig = pm.createPdf.bind(pm); pm.__jlrOrig = orig;
    pm.createPdf = function (dd, ...args) { return wrapDoc(pm, dd, orig(dd, ...args), args); };
    return pm;
  }
  let cur = window.pdfMake;
  try {
    Object.defineProperty(window, 'pdfMake', { configurable: true, enumerable: true, get() { return wrap(cur); }, set(v) { cur = v; wrap(cur); } });
  } catch { setInterval(() => wrap(window.pdfMake), 1500); }
})();
