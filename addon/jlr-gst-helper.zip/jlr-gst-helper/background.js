// JLR GST Helper — background
// 1) talks to the tracker (gst-helper function) with the staff member's add-on key
// 2) reads GST portal data from the other portal sites (return / gstr2b / services) using the portal login already open in Chrome
const DEF = { server: 'https://bakvbqtbhdumvlioenyw.supabase.co', tracker: 'https://jlr-compliance.github.io/' };
const HOSTS = ['services.gst.gov.in', 'return.gst.gov.in', 'gstr2b.gst.gov.in'];

async function cfg() { const s = await chrome.storage.local.get(['key', 'server', 'tracker', 'name']); return { ...DEF, ...Object.fromEntries(Object.entries(s).filter(([, v]) => v)) }; }

async function tracker(body) {
  const c = await cfg();
  if (!c.key) return { error: 'Add your tracker key first — click the JLR add-on icon in the Chrome toolbar.' };
  try {
    const r = await fetch(`${c.server.replace(/\/$/, '')}/functions/v1/gst-helper`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-jlr-key': c.key }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({ error: `Tracker answered ${r.status}` }));
    if (!r.ok && !j.error) j.error = `Tracker answered ${r.status}`;
    return j;
  } catch (e) { return { error: 'Cannot reach the tracker — check the internet' }; }
}

// Read a portal API on another portal site (e.g. GSTR-2B lives on gstr2b.gst.gov.in).
// First a direct read; if the portal does not see the login that way, open a quiet background tab on that site,
// read from inside it (same site = the portal sees the staff member's own login), then close the tab.
function inPage(path, method, body) {
  return fetch(path, { method, credentials: 'include', headers: body ? { 'content-type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined })
    .then(async r => { const t = await r.text(); try { return { status: r.status, json: JSON.parse(t) }; } catch { return { status: r.status, error: 'not-json' }; } })
    .catch(() => ({ error: 'network' }));
}
const helperTabs = {};   // host -> { id, ready: Promise, timer }
function helperTab(host) {
  const h = helperTabs[host];
  if (h) { clearTimeout(h.timer); h.timer = setTimeout(() => closeHelper(host), 30000); return h.ready; }
  const t = { timer: setTimeout(() => closeHelper(host), 30000) };
  t.ready = new Promise((res, rej) => {
    chrome.tabs.create({ url: `https://${host}/services/api/ustatus`, active: false }, tab => {
      if (!tab) return rej(new Error('tab'));
      t.id = tab.id;
      const done = (id, info) => { if (id === tab.id && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(done); res(tab.id); } };
      chrome.tabs.onUpdated.addListener(done);
      setTimeout(() => { chrome.tabs.onUpdated.removeListener(done); res(tab.id); }, 15000);
    });
  });
  helperTabs[host] = t; return t.ready;
}
function closeHelper(host) { const h = helperTabs[host]; delete helperTabs[host]; if (h && h.id) chrome.tabs.remove(h.id).catch(() => {}); }

// v59/v60: upload to the portal — runs inside a Returns page tab (same site), the same calls as Prepare offline → Upload.
// GSTR-1: the JSON made in the tracker. GSTR-3B: read the client's current 3B from the portal, replace the tables the tracker
// works out (3.1, 4), keep the rest (3.2, 5, interest) as the portal has it, then upload.
function uploadInPage(kind, payload, rtnPrd, fname, gstin) {
  const xsrf = (document.cookie.match(/(?:^|;\s*)XSRF-TOKEN=([^;]+)/) || [])[1];
  const H = xsrf ? { 'X-XSRF-TOKEN': decodeURIComponent(xsrf) } : {};
  const err = j => (j && j.error && (j.error.message || j.error.errorCode)) || '';
  const J = { accept: 'application/json, text/plain, */*', ...H };
  return (async () => {
    try {
      let body = payload;
      if (kind === 'gstr3b') {
        const r0 = await fetch('/returns/auth/api/gstr3b/summary?rtn_prd=' + rtnPrd, { credentials: 'include', headers: J });
        let j0; try { j0 = JSON.parse(await r0.text()); } catch { return { step: 0, error: 'not-json', http: r0.status }; }
        const d = j0 && (j0.data || j0); if (!d || !d.sup_details) return { step: 0, error: err(j0) || 'Could not read the GSTR-3B from the portal' };
        const F = payload.figs || {}, Z = { t: 0, ig: 0, cg: 0, sg: 0, cs: 0 }, f = k => F[k] || Z;
        const amt = (x, noT) => ({ ...(noT ? {} : { txval: x.t }), iamt: x.ig, camt: x.cg, samt: x.sg, csamt: x.cs });
        const sd = JSON.parse(JSON.stringify(d.sup_details));
        sd.osup_det = amt(f('a')); sd.osup_zero = { txval: f('b').t, iamt: f('b').ig, csamt: f('b').cs }; sd.osup_nil_exmp = { txval: f('c').t };
        sd.isup_rev = amt(f('d')); sd.osup_nongst = { txval: f('e').t };
        const ie = JSON.parse(JSON.stringify(d.itc_elg || {})), AV = { IMPG: 'imp', ISRC: 'rcm', ISD: 'isd', OTH: 'a5' }, RV = { RUL: 'B1', OTH: 'B2' }, IN = { RUL: 'D1', OTH: 'D2' };
        const put = (list, map) => (list || []).map(x => map[x.ty] ? { ty: x.ty, ...amt(f(map[x.ty]), true) } : x);
        ie.itc_avl = put(ie.itc_avl, AV); ie.itc_rev = put(ie.itc_rev, RV); ie.itc_inelg = put(ie.itc_inelg, IN); ie.itc_net = amt(f('C'), true);
        body = { gstin, ret_period: rtnPrd, sup_details: sd, itc_elg: ie };
        ['eco_dtls', 'inter_sup', 'inward_sup', 'intr_ltfee'].forEach(k => { if (d[k]) body[k] = d[k]; });
      }
      const text = JSON.stringify(body), blob = new Blob([text], { type: 'application/json' });
      const fd = new FormData(); fd.append('upfile', blob, fname); fd.append('ty', 'ROUZ'); fd.append('rtn_typ', kind === 'gstr3b' ? 'GSTR3B' : 'GSTR1'); fd.append('ret_period', rtnPrd);
      const r1 = await fetch('/returndocs/offline/upload', { method: 'POST', body: fd, credentials: 'include', headers: { sz: String(blob.size), ...H } });
      const t1 = await r1.text(); let j1; try { j1 = JSON.parse(t1); } catch { return { step: 1, error: 'not-json', http: r1.status }; }
      if (String(j1.status) !== '1') return { step: 1, error: err(j1) || 'The portal did not take the file', raw: j1 };
      j1.fp = rtnPrd;
      const r2 = await fetch(kind === 'gstr3b' ? '/returns/auth/api/gstr3b/upload' : '/returns/auth/api/gstr1/upload', { method: 'POST', credentials: 'include', headers: { 'content-type': 'application/json;charset=utf-8', ...J }, body: JSON.stringify(j1) });
      const t2 = await r2.text(); let j2; try { j2 = JSON.parse(t2); } catch { return { step: 2, error: 'not-json', http: r2.status }; }
      if (String(j2.status) !== '1') return { step: 2, error: err(j2) || 'The portal did not accept the upload', raw: j2 };
      return { ok: true, raw: j2, sent: kind === 'gstr3b' ? body : null };
    } catch (e) { return { error: String(e && e.message || e) }; }
  })();
}
async function uploadToPortal({ kind, payload, rtnPrd, fname, gstin }) {
  try {
    const id = await helperTab('return.gst.gov.in');
    const [res] = await chrome.scripting.executeScript({ target: { tabId: id }, func: uploadInPage, args: [kind || 'gstr1', payload, rtnPrd, fname, gstin] });
    return (res && res.result) || { error: 'No answer from the portal page' };
  } catch (e) { return { error: 'Could not open the Returns page: ' + (e && e.message || e) }; }
}

async function portal({ url, method = 'GET', body }) {
  const u = new URL(url);
  if (!HOSTS.includes(u.hostname)) return { error: 'Not a GST portal address' };
  let r;
  try {
    const x = await fetch(url, { method, credentials: 'include', headers: body ? { 'content-type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
    const t = await x.text(); try { r = { status: x.status, json: JSON.parse(t) }; } catch { r = { status: x.status, error: 'not-json' }; }
  } catch { r = { error: 'network' }; }
  if (r.json) return r;
  try {
    const id = await helperTab(u.hostname);
    const [res] = await chrome.scripting.executeScript({ target: { tabId: id }, func: inPage, args: [u.pathname + u.search, method, body || null] });
    return (res && res.result) || { error: 'not-json' };
  } catch (e) { return { error: 'not-json' }; }
}


// ---------- v1.5.0: GSTR-1 / GSTR-3B PDFs (draft and filed) ----------
// hook.js keeps a copy of every GSTR-1 / GSTR-3B PDF the portal makes; it is queued here and handed to the tracker page
// (tracker.js), which saves it with the staff member's own tracker login. The portal's own download still goes to the computer.
const PDFQ = 'pdfq', DONE = 'pdfdone', PLOG = 'pdflog', DAY = 864e5;
const pdfTabs = new Set();
function parsePdf({ name, b64, wm, texts }) {
  const m = String(name || '').match(/^(GSTR1|IFF|GSTR3B)_([0-9A-Z]{15})_(\d{2})(\d{4})\.pdf$/i); if (!m || !b64) return null;
  const kind = /3B/i.test(m[1]) ? 'gstr3b' : 'gstr1', stage = /FILED|FINAL/i.test(wm || '') ? 'filed' : 'draft', month = `${m[4]}-${m[3]}`;
  const T = (texts || []).map(x => String(x).trim()), after = re => { const i = T.findIndex(x => re.test(x)); return i >= 0 ? (T[i + 1] || '') : ''; };
  const arn = (after(/(^|\W)ARN$/i).match(/^[A-Z0-9]{14,16}$/) || [])[0] || '';
  const ad = (after(/date of arn|arn date/i).match(/^\d{2}[\/-]\d{2}[\/-]\d{4}$/) || [])[0] || '';
  return { key: `${m[2].toUpperCase()}|${month}|${kind}|${stage}`, gstin: m[2].toUpperCase(), month, kind, stage, name, b64, arn, arnDate: ad, at: Date.now() };
}
async function trackerTabs() { const c = await cfg(); const base = (c.tracker || DEF.tracker).replace(/\/?$/, '/'); try { return await chrome.tabs.query({ url: base + '*' }); } catch { return []; } }
async function queuePdf(raw) {
  const p = parsePdf(raw); if (!p) return { error: 'Not a GSTR-1 / GSTR-3B PDF' };
  const s = await chrome.storage.local.get([PDFQ, DONE]);
  const q = (s[PDFQ] || []).filter(x => x.key !== p.key); q.push(p); while (q.length > 40) q.shift();
  const done = s[DONE] || {}; done[p.key] = Date.now();
  await chrome.storage.local.set({ [PDFQ]: q, [DONE]: done });
  const tabs = await trackerTabs(); tabs.forEach(t => chrome.tabs.sendMessage(t.id, { type: 'pdfq_new' }).catch(() => {}));
  return { ok: true, key: p.key, kind: p.kind, stage: p.stage, waiting: q.length, trackerOpen: tabs.length > 0 };
}
async function pdfDone(results) {
  const s = await chrome.storage.local.get([PDFQ, PLOG]), gone = new Set((results || []).filter(r => r && r.final).map(r => r.key));
  const q = (s[PDFQ] || []).filter(x => !gone.has(x.key));
  const log = (s[PLOG] || []).concat((results || []).map(r => ({ key: r.key, ok: !!r.ok, msg: r.msg || '', at: Date.now() }))).slice(-40);
  await chrome.storage.local.set({ [PDFQ]: q, [PLOG]: log }); return { ok: true, left: q.length };
}
// ----- automatic: open the Returns dashboard in a quiet tab, pick the month, and press the portal's own PDF buttons -----
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const sleep = ms => new Promise(r => setTimeout(r, ms));
const run = async (tabId, func, args = []) => { try { const [r] = await chrome.scripting.executeScript({ target: { tabId }, func, args }); return r && r.result; } catch { return null; } };
function loaded(tabId, ms = 20000) { return new Promise(res => { let t; const f = (id, info) => { if (id === tabId && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(f); clearTimeout(t); res(true); } }; chrome.tabs.onUpdated.addListener(f); t = setTimeout(() => { chrome.tabs.onUpdated.removeListener(f); res(false); }, ms); }); }
async function waitFor(tabId, func, args, ms = 15000) { const end = Date.now() + ms; while (Date.now() < end) { const r = await run(tabId, func, args); if (r) return r; await sleep(700); } return null; }
async function waitDone(key, since, ms = 25000) { const keys = [].concat(key), end = Date.now() + ms; while (Date.now() < end) { const s = await chrome.storage.local.get(DONE); const hit = keys.find(x => ((s[DONE] || {})[x] || 0) >= since); if (hit) return hit; await sleep(800); } return null; }
// page helpers (run inside the portal tab)
function pgPick(fy, q, mon) {
  const S = n => document.querySelector(`select[name=${n}]`); if (!S('fin') || !S('mon')) return null;
  const set = (sel, txt) => { const o = [...sel.options].find(o => o.text.trim() === txt); if (!o) return false; sel.value = o.value; sel.dispatchEvent(new Event('change', { bubbles: true })); return true; };
  if (!set(S('fin'), fy)) return { error: 'year' };
  return new Promise(res => setTimeout(() => { if (S('quarter')) set(S('quarter'), q);
    setTimeout(() => { if (!set(S('mon'), mon)) { res({ error: 'month' }); return; } setTimeout(() => { const b = [...document.querySelectorAll('button')].find(x => /^\s*search\s*$/i.test(x.textContent)); if (b) b.click(); res({ ok: true }); }, 400); }, 700); }, 600));
}
function pgTiles() {
  const btns = [...document.querySelectorAll('button')].filter(b => b.offsetParent);
  if (!btns.some(b => /page_rtp|offlinepath|downloadGSTR3Bpdf/.test(b.getAttribute('data-ng-click') || ''))) return null;
  const T = document.body.innerText || '', st = n => ((T.match(new RegExp('\\n' + n + '\\s*\\n+\\s*Status\\s*-\\s*([^\\n]+)')) || [])[1] || '').trim();
  return { g1Filed: /^Filed/i.test(st('GSTR-1')), g3Filed: /^Filed/i.test(st('GSTR-3B')), g3Dl: btns.some(b => /downloadGSTR3Bpdf/.test(b.getAttribute('data-ng-click') || '')) };
}
function pgClick(re, attrRe) { const b = [...document.querySelectorAll('button,a')].find(x => x.offsetParent && (attrRe ? new RegExp(attrRe).test(x.getAttribute('data-ng-click') || x.getAttribute('ng-click') || '') : new RegExp(re, 'i').test((x.textContent || '').trim()))); if (!b) return null; b.click(); return true; }
function pgG1View() {
  const tileName = x => { let p = x; for (let i = 0; i < 8 && p; i++, p = p.parentElement) { const L = (p.innerText || '').split('\n').map(s => s.trim()).find(s => /^GSTR-\w+$/.test(s)); if (L) return L; } return ''; };
  const b = [...document.querySelectorAll('button')].find(x => x.offsetParent && /page_rtp/.test(x.getAttribute('data-ng-click') || '') && tileName(x) === 'GSTR-1'); if (!b) return null; b.click(); return true; }
const running = new Set();
async function autoPdf({ gstin, month, force }, sender) {
  if (sender && sender.tab && pdfTabs.has(sender.tab.id)) return { skipped: 'helper' };
  const s = await chrome.storage.local.get([DONE, 'autoPdfOff']); if (s.autoPdfOff && !force) return { skipped: 'off' };
  const G = String(gstin || '').toUpperCase(), job = G + '|' + month; if (!/^\d{4}-\d{2}$/.test(month || '') || !G) return { error: 'bad month' };
  if (running.has(job)) return { skipped: 'running' };
  const done = s[DONE] || {}, k = x => `${G}|${month}|${x}`, have = (x, ms) => done[k(x)] && Date.now() - done[k(x)] < ms;
  if (have('gstr1|filed', 400 * DAY) && have('gstr3b|filed', 400 * DAY) && !force) return { skipped: 'have', got: [] };
  running.add(job); const got = [], note = [];
  let tabId = null;
  try {
    const y = +month.slice(0, 4), mo = +month.slice(5, 7), fs = mo >= 4 ? y : y - 1, fy = `${fs}-${String(fs + 1).slice(2)}`;
    const q = mo <= 3 ? 'Quarter 4 (Jan - Mar)' : mo <= 6 ? 'Quarter 1 (Apr - Jun)' : mo <= 9 ? 'Quarter 2 (Jul - Sep)' : 'Quarter 3 (Oct - Dec)';
    const tab = await chrome.tabs.create({ url: 'https://return.gst.gov.in/services/api/ustatus', active: false }); tabId = tab.id; pdfTabs.add(tabId);
    await loaded(tabId);
    await run(tabId, () => { location.href = '/returns/auth/dashboard'; return true; }); await sleep(2500);
    if (!await waitFor(tabId, () => !!document.querySelector('select[name=mon]'))) return { error: 'The Returns dashboard did not open — is the portal still logged in?' };
    const pk = await waitFor(tabId, pgPick, [fy, q, MONTHS[mo - 1]], 8000); if (!pk || pk.error) return { error: 'Could not pick ' + month + ' on the portal' };
    const T = await waitFor(tabId, pgTiles, [], 15000); if (!T) return { error: 'The portal did not show the returns for ' + month };
    // GSTR-3B: filed PDF from the dashboard tile (draft 3B is taken when staff press "Preview draft GSTR-3B" — opening the 3B form makes the portal save its own interest figures)
    if (T.g3Dl && !have('gstr3b|filed', 400 * DAY)) { const t0 = Date.now(); if (await run(tabId, pgClick, ['', 'downloadGSTR3Bpdf']) && await waitDone(k('gstr3b|filed'), t0)) got.push('GSTR-3B filed'); else note.push('GSTR-3B filed PDF not taken'); }
    else if (!T.g3Dl) note.push('GSTR-3B not filed yet — its draft PDF is kept when you press “Preview draft GSTR-3B”');
    const g1stage = T.g1Filed ? 'filed' : 'draft';
    if (!have('gstr1|' + g1stage, g1stage === 'filed' ? 400 * DAY : 20 * 3600e3) || force) {
      const t0 = Date.now();
      if (await run(tabId, pgG1View)) {
        await sleep(2500);
        if (await waitFor(tabId, pgClick, ['view summary$'], 15000)) {
          await sleep(2500);
          let hit = null; if (await waitFor(tabId, pgClick, ['', 'genratepdfNew'], 20000)) hit = await waitDone([k('gstr1|filed'), k('gstr1|draft')], t0, 30000);
          if (hit) got.push('GSTR-1 ' + hit.split('|').pop());
          else note.push('GSTR-1 PDF not taken');
        } else note.push('GSTR-1 summary did not open');
      } else note.push('GSTR-1 tile not found');
    }
    return { ok: true, got, note };
  } catch (e) { return { error: String(e && e.message || e) }; }
  finally { running.delete(job); if (tabId) { pdfTabs.delete(tabId); setTimeout(() => chrome.tabs.remove(tabId).catch(() => {}), 4000); } }
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  (async () => {
    if (msg.type === 'tracker') return tracker(msg.body);
    if (msg.type === 'portal') return portal(msg);
    if (msg.type === 'upload') return uploadToPortal(msg);
    if (msg.type === 'cfg') { const c = await cfg(); const a = await chrome.storage.local.get(['autoPdfOff', PDFQ]); return { hasKey: !!c.key, name: c.name || '', tracker: c.tracker, autoPdf: !a.autoPdfOff, waiting: (a[PDFQ] || []).length }; }
    if (msg.type === 'pdf') return queuePdf(msg);
    if (msg.type === 'pdfq_get') { const a = await chrome.storage.local.get(PDFQ); return { items: a[PDFQ] || [] }; }
    if (msg.type === 'pdfq_done') return pdfDone(msg.results);
    if (msg.type === 'pdflog') { const a = await chrome.storage.local.get([PLOG, PDFQ]); return { log: a[PLOG] || [], waiting: (a[PDFQ] || []).map(x => ({ key: x.key, at: x.at })) }; }
    if (msg.type === 'autopdf') return autoPdf(msg, sender);
    if (msg.type === 'openTracker') { const t = await trackerTabs(); if (t.length) { chrome.tabs.update(t[0].id, { active: true }); return { ok: true }; } const c = await cfg(); chrome.tabs.create({ url: c.tracker || DEF.tracker }); return { ok: true }; }
    return { error: 'unknown' };
  })().then(reply, e => reply({ error: String(e && e.message || e) }));
  return true;
});
