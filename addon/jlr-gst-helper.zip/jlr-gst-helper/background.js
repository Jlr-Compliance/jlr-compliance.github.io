// JLR GST Helper — background
// 1) talks to the tracker (gst-helper function) with the staff member's add-on key
// 2) reads GST portal data from the other portal sites (return / gstr2b / services) using the portal login already open in Chrome
const DEF = { server: 'https://bakvbqtbhdumvlioenyw.supabase.co', tracker: 'https://jlr-compliance.github.io/' };
const HOSTS = ['services.gst.gov.in', 'return.gst.gov.in', 'gstr2b.gst.gov.in'];

async function cfg() { const s = await chrome.storage.local.get(['key', 'server', 'tracker', 'name']); return { ...DEF, ...Object.fromEntries(Object.entries(s).filter(([, v]) => v)) }; }

async function tracker(body) {
  const c = await cfg();
  if (!c.key) return { error: 'Add your tracker key first — click the JLR add-on icon in the Chrome toolbar.' };
  try {
    const r = await fetch(`${c.server.replace(/\/$/, '')}/functions/v1/gst-helper`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-jlr-key': c.key }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({ error: `Tracker answered ${r.status}` }));
    if (!r.ok && !j.error) j.error = `Tracker answered ${r.status}`;
    return j;
  } catch (e) { return { error: 'Cannot reach the tracker — check the internet' }; }
}

// Read a portal API on another portal site (e.g. GSTR-2B lives on gstr2b.gst.gov.in).
// First a direct read; if the portal does not see the login that way, open a quiet background tab on that site,
// read from inside it (same site = the portal sees the staff member's own login), then close the tab.
function inPage(path, method, body) {
  return fetch(path, { method, credentials: 'include', headers: body ? { 'content-type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined })
    .then(async r => { const t = await r.text(); try { return { status: r.status, json: JSON.parse(t) }; } catch { return { status: r.status, error: 'not-json' }; } })
    .catch(() => ({ error: 'network' }));
}
const helperTabs = {};   // host -> { id, ready: Promise, timer }
function helperTab(host) {
  const h = helperTabs[host];
  if (h) { clearTimeout(h.timer); h.timer = setTimeout(() => closeHelper(host), 30000); return h.ready; }
  const t = { timer: setTimeout(() => closeHelper(host), 30000) };
  t.ready = new Promise((res, rej) => {
    chrome.tabs.create({ url: `https://${host}/services/api/ustatus`, active: false }, tab => {
      if (!tab) return rej(new Error('tab'));
      t.id = tab.id;
      const done = (id, info) => { if (id === tab.id && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(done); res(tab.id); } };
      chrome.tabs.onUpdated.addListener(done);
      setTimeout(() => { chrome.tabs.onUpdated.removeListener(done); res(tab.id); }, 15000);
    });
  });
  helperTabs[host] = t; return t.ready;
}
function closeHelper(host) { const h = helperTabs[host]; delete helperTabs[host]; if (h && h.id) chrome.tabs.remove(h.id).catch(() => {}); }

// v59/v60: upload to the portal — runs inside a Returns page tab (same site), the same calls as Prepare offline → Upload.
// GSTR-1: the JSON made in the tracker. GSTR-3B: read the client's current 3B from the portal, replace the tables the tracker
// works out (3.1, 4), keep the rest (3.2, 5, interest) as the portal has it, then upload.
function uploadInPage(kind, payload, rtnPrd, fname, gstin) {
  const xsrf = (document.cookie.match(/(?:^|;\s*)XSRF-TOKEN=([^;]+)/) || [])[1];
  const H = xsrf ? { 'X-XSRF-TOKEN': decodeURIComponent(xsrf) } : {};
  const err = j => (j && j.error && (j.error.message || j.error.errorCode)) || '';
  const J = { accept: 'application/json, text/plain, */*', ...H };
  return (async () => {
    try {
      let body = payload;
      if (kind === 'gstr3b') {
        const r0 = await fetch('/returns/auth/api/gstr3b/summary?rtn_prd=' + rtnPrd, { credentials: 'include', headers: J });
        let j0; try { j0 = JSON.parse(await r0.text()); } catch { return { step: 0, error: 'not-json', http: r0.status }; }
        const d = j0 && (j0.data || j0); if (!d || !d.sup_details) return { step: 0, error: err(j0) || 'Could not read the GSTR-3B from the portal' };
        const F = payload.figs || {}, Z = { t: 0, ig: 0, cg: 0, sg: 0, cs: 0 }, f = k => F[k] || Z;
        const amt = (x, noT) => ({ ...(noT ? {} : { txval: x.t }), iamt: x.ig, camt: x.cg, samt: x.sg, csamt: x.cs });
        const sd = JSON.parse(JSON.stringify(d.sup_details));
        sd.osup_det = amt(f('a')); sd.osup_zero = { txval: f('b').t, iamt: f('b').ig, csamt: f('b').cs }; sd.osup_nil_exmp = { txval: f('c').t };
        sd.isup_rev = amt(f('d')); sd.osup_nongst = { txval: f('e').t };
        const ie = JSON.parse(JSON.stringify(d.itc_elg || {})), AV = { IMPG: 'imp', ISRC: 'rcm', ISD: 'isd', OTH: 'a5' }, RV = { RUL: 'B1', OTH: 'B2' }, IN = { RUL: 'D1', OTH: 'D2' };
        const put = (list, map) => (list || []).map(x => map[x.ty] ? { ty: x.ty, ...amt(f(map[x.ty]), true) } : x);
        ie.itc_avl = put(ie.itc_avl, AV); ie.itc_rev = put(ie.itc_rev, RV); ie.itc_inelg = put(ie.itc_inelg, IN); ie.itc_net = amt(f('C'), true);
        body = { gstin, ret_period: rtnPrd, sup_details: sd, itc_elg: ie };
        ['eco_dtls', 'inter_sup', 'inward_sup', 'intr_ltfee'].forEach(k => { if (d[k]) body[k] = d[k]; });
      }
      const text = JSON.stringify(body), blob = new Blob([text], { type: 'application/json' });
      const fd = new FormData(); fd.append('upfile', blob, fname); fd.append('ty', 'ROUZ'); fd.append('rtn_typ', kind === 'gstr3b' ? 'GSTR3B' : 'GSTR1'); fd.append('ret_period', rtnPrd);
      const r1 = await fetch('/returndocs/offline/upload', { method: 'POST', body: fd, credentials: 'include', headers: { sz: String(blob.size), ...H } });
      const t1 = await r1.text(); let j1; try { j1 = JSON.parse(t1); } catch { return { step: 1, error: 'not-json', http: r1.status }; }
      if (String(j1.status) !== '1') return { step: 1, error: err(j1) || 'The portal did not take the file', raw: j1 };
      j1.fp = rtnPrd;
      const r2 = await fetch(kind === 'gstr3b' ? '/returns/auth/api/gstr3b/upload' : '/returns/auth/api/gstr1/upload', { method: 'POST', credentials: 'include', headers: { 'content-type': 'application/json;charset=utf-8', ...J }, body: JSON.stringify(j1) });
      const t2 = await r2.text(); let j2; try { j2 = JSON.parse(t2); } catch { return { step: 2, error: 'not-json', http: r2.status }; }
      if (String(j2.status) !== '1') return { step: 2, error: err(j2) || 'The portal did not accept the upload', raw: j2 };
      return { ok: true, raw: j2, sent: kind === 'gstr3b' ? body : null };
    } catch (e) { return { error: String(e && e.message || e) }; }
  })();
}
async function uploadToPortal({ kind, payload, rtnPrd, fname, gstin }) {
  try {
    const id = await helperTab('return.gst.gov.in');
    const [res] = await chrome.scripting.executeScript({ target: { tabId: id }, func: uploadInPage, args: [kind || 'gstr1', payload, rtnPrd, fname, gstin] });
    return (res && res.result) || { error: 'No answer from the portal page' };
  } catch (e) { return { error: 'Could not open the Returns page: ' + (e && e.message || e) }; }
}

async function portal({ url, method = 'GET', body }) {
  const u = new URL(url);
  if (!HOSTS.includes(u.hostname)) return { error: 'Not a GST portal address' };
  let r;
  try {
    const x = await fetch(url, { method, credentials: 'include', headers: body ? { 'content-type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
    const t = await x.text(); try { r = { status: x.status, json: JSON.parse(t) }; } catch { r = { status: x.status, error: 'not-json' }; }
  } catch { r = { error: 'network' }; }
  if (r.json) return r;
  try {
    const id = await helperTab(u.hostname);
    const [res] = await chrome.scripting.executeScript({ target: { tabId: id }, func: inPage, args: [u.pathname + u.search, method, body || null] });
    return (res && res.result) || { error: 'not-json' };
  } catch (e) { return { error: 'not-json' }; }
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  (async () => {
    if (msg.type === 'tracker') return tracker(msg.body);
    if (msg.type === 'portal') return portal(msg);
    if (msg.type === 'upload') return uploadToPortal(msg);
    if (msg.type === 'cfg') { const c = await cfg(); return { hasKey: !!c.key, name: c.name || '', tracker: c.tracker }; }
    return { error: 'unknown' };
  })().then(reply, e => reply({ error: String(e && e.message || e) }));
  return true;
});
