// JLR GST Helper — runs on the GST portal pages.
// After the staff member logs in (password + captcha typed by them), a "JLR" button appears.
// It reads only what the portal already shows to the logged-in taxpayer and sends it to the tracker.
// It never files, submits, saves or changes anything on the portal, and never touches the login details.
(() => {
  if (window.__jlrg) return; window.__jlrg = true;
  const R = 'return.gst.gov.in', S = 'services.gst.gov.in', B = 'gstr2b.gst.gov.in';
  const GSTIN_RE = /\b[0-9]{2}[A-Z0-9]{10}[0-9A-Z]Z[0-9A-Z]\b/;
  const MN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const send = msg => new Promise(res => { try { chrome.runtime.sendMessage(msg, r => res(r || { error: chrome.runtime.lastError ? 'The add-on was updated — reload this page' : 'No answer' })); } catch { res({ error: 'The add-on was updated — reload this page' }); } });

  // ---------- who is logged in ----------
  function loggedGstin() {
    const out = [...document.querySelectorAll('a')].find(a => /^\s*logout\s*$/i.test(a.textContent || ''));
    if (!out) return null;
    let el = out; for (let i = 0; i < 8 && el; i++, el = el.parentElement) { const m = (el.textContent || '').match(GSTIN_RE); if (m) return m[0]; }
    const head = document.querySelector('header, .navbar, .top-header') || document.body; const m = (head.innerText || '').slice(0, 3000).match(GSTIN_RE);
    return m ? m[0] : null;
  }

  // ---------- reading the portal ----------
  async function get(host, path, opt = {}) {
    const url = `https://${host}${path}`;
    if (host === location.hostname) {
      try {
        const r = await fetch(path, { method: opt.method || 'GET', credentials: 'include', headers: opt.body ? { 'content-type': 'application/json' } : {}, body: opt.body ? JSON.stringify(opt.body) : undefined });
        const t = await r.text(); try { return { status: r.status, json: JSON.parse(t) }; } catch { return { status: r.status, error: 'not-json' }; }
      } catch { return { error: 'network' }; }
    }
    return send({ type: 'portal', url, method: opt.method, body: opt.body });
  }
  const hostName = h => ({ [R]: 'Returns', [S]: 'Dashboard', [B]: 'GSTR-2B' }[h]);
  function fail(r, host) {
    if (r && r.json && r.json.error) return (r.json.error.message || r.json.error.errorCode || 'Portal error') + '';
    if (r && r.error === 'not-json') return `The portal did not give data — if the portal logged you out, log in again; otherwise open the ${hostName(host)} page once from the portal menu and press Send again`;
    return (r && r.error) || 'Portal did not answer';
  }
  const ok = r => r && r.json && !r.json.error && (r.json.status === undefined || r.json.status === 1 || r.json.status === 200 || r.json.data);

  // ---------- v1.7.0 (stage 2): read ledgers, TDS / TCS credit, applications, LUTs, certificates, PMT-03A and notices issued — read only ----------
  const PAY = 'payment.gst.gov.in';
  const dmy = d => `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
  async function readInfo(gstin) {
    const out = { at: new Date().toISOString(), errors: [] }, now = new Date(), fyStart = new Date(now.getMonth() >= 3 ? now.getFullYear() : now.getFullYear() - 1, 3, 1);
    const val = (r, name) => { if (r && r.json && !(r.json.error || r.json.errorCode || r.json.status_cd === '0' || r.json.status === 0)) return r.json.data !== undefined && r.json.status !== undefined ? r.json.data : r.json;
      const e = r && r.json && (r.json.error || r.json); const msg = e && (e.message || e.errorCode || e.error_cd) || (r && r.error) || 'no answer';
      if (!/no (data|record|invoice)/i.test(String(msg)) && !/LG9029|RETWEB_04|SWEB_10001|SWEB_8000/.test(JSON.stringify(e || ''))) out.errors.push(`${name}: ${msg}`); return null; };
    const tasks = [
      ['credit', () => get(R, '/returns/auth/api/itcbalance')],
      ['creditTx', () => get(R, `/returns/auth/api/itcdtls?fdate=${encodeURIComponent(dmy(fyStart))}&tdate=${encodeURIComponent(dmy(now))}`)],
      ['liab', () => get(R, '/returns/auth/api/getopenliabilities')],
      ['cash', () => get(PAY, '/payment/auth/api/cashbalance')],
      ['cashTx', () => get(PAY, `/payment/auth/api/cashdetls?fdate=${encodeURIComponent(dmy(fyStart))}&tdate=${encodeURIComponent(dmy(now))}`)],
      ['certs', () => get(S, '/services/auth/api/get/certs')],
      ['drafts', () => get(S, '/services/auth/api/myapp')],
      ['pmt03a', () => get(S, '/litserv/auth/api/order/getStandAloneOrders', { method: 'POST', body: { formType: 'PMT03A', gstin } })],
      ['notices60', () => get(S, '/services2/auth/api/getlistofnotices')]];
    for (const [k, f] of tasks) { try { out[k] = val(await f(), k); } catch (e) { out.errors.push(`${k}: ${e}`); } }
    // applications by type (My Applications): LUT, DRC-03, refunds, appeals, composition, advance ruling …
    const from = dmy(new Date(now.getFullYear() - 2, now.getMonth(), now.getDate())), to = dmy(now);
    out.cases = {};
    for (const [code, label] of [['LETUT', 'LUT (RFD-11)'], ['ADVPD', 'DRC-03'], ['RFUND', 'Refund'], ['APPEL', 'Appeal (APL-01)'], ['COMPD', 'Composition'], ['ARARA', 'Advance ruling']]) {
      try { const r = await get(S, '/litserv/auth/api/case/search', { method: 'POST', body: { caseTypeCd: code, startDate: from, endDate: to } }); const v = val(r, code); if (Array.isArray(v) && v.length) out.cases[code] = { label, list: v.slice(0, 50) }; } catch (e) { out.errors.push(`${code}: ${e}`); }
    }
    // submitted applications with status (Track Application Status, last 6 months) and registration ARNs
    try { const r = await get(S, `/services/auth/api/trackarn?type=2&stdt=${encodeURIComponent(dmy(new Date(now.getFullYear(), now.getMonth() - 6, now.getDate() + 1)))}&endt=${encodeURIComponent(dmy(now))}`); const v = val(r, 'trackarn');
      const L = Array.isArray(v) ? v : v && (v.arnEntity || v.list || v.data); out.arns = Array.isArray(L) ? L.slice(0, 100) : []; } catch (e) { out.errors.push(`trackarn: ${e}`); }
    try { const v = val(await get(S, '/services/auth/api/getarn'), 'getarn'); if (Array.isArray(v)) out.arns = (out.arns || []).concat(v.filter(x => !(out.arns || []).some(y => y.arn === x.arn)).slice(0, 50)); } catch (e) { out.errors.push(`getarn: ${e}`); }
    // status of every return type (Returns dashboard) for the last 3 months — other returns like IFF, CMP-08, GSTR-7 / 8 / 1A
    out.returns = {};
    for (let i = 1; i <= 3; i++) { const d = new Date(now.getFullYear(), now.getMonth() - i, 1), prd = `${String(d.getMonth() + 1).padStart(2, '0')}${d.getFullYear()}`;
      try { const v = val(await get(R, `/returns/auth/api/rolestatus?rtn_prd=${prd}`), 'rolestatus'); const L = []; ((v && v.user) || []).forEach(u => (u.returns || []).forEach(x => L.push({ return_ty: x.return_ty, status: x.status, due_dt: x.due_dt }))); out.returns[prd] = L; } catch (e) { out.errors.push(`rolestatus: ${e}`); } }
    // TDS / TCS credit received (GSTR-2X): the last 3 months
    out.gstr2x = {};
    for (let i = 1; i <= 3; i++) { const d = new Date(now.getFullYear(), now.getMonth() - i, 1), prd = `${String(d.getMonth() + 1).padStart(2, '0')}${d.getFullYear()}`;
      try { const v = val(await get(R, `/returns2/auth/api/gstr2x/summary?rtn_prd=${prd}`), 'gstr2x'); if (v) out.gstr2x[prd] = v.summary || v; } catch (e) { out.errors.push(`gstr2x: ${e}`); } }
    // GSTR-9 system figures for the last financial year (what the portal auto-fills): tables 4, 5, 6, 8A, 9 + GSTR-1 / 3B yearly sums
    try { const fyEnd = now.getMonth() >= 3 ? now.getFullYear() : now.getFullYear() - 1, rp = `03${fyEnd}`, q = `ret_period=${rp}&gstin=${gstin}`;
      const calc = val(await get(R, `/returns2/auth/api/gstr9/details/calc?${q}`), 'gstr9 calc');
      if (calc) { const g3 = val(await get(R, `/returns2/auth/api/gstr9/gstr3bsumm?${q}`), 'gstr9 3b'), g1 = val(await get(R, `/returns2/auth/api/gstr9/gstr1summ?${q}`), 'gstr9 1'), sm = val(await get(R, `/returns2/auth/api/gstr9/summary?fp=${rp}`), 'gstr9 summary');
        if (g3 && g3.tx_pay_dtls) delete g3.tx_pay_dtls;
        out.gstr9 = { fy: `${fyEnd - 1}-${String(fyEnd).slice(2)}`, rp, calc, g3, g1: g1 && (g1.gstr1summary || g1), saved: sm }; } } catch (e) { out.errors.push(`gstr9: ${e}`); }
    return out;
  }
  async function sendInfo(g) { const data = await readInfo(g); const r = await send({ type: 'info', gstin: g, data }); return { data, r }; }
  const STEPS = [
    { id: 'status', label: 'Return status (filed / not filed)', host: R, run: async p => { const r = await get(R, `/returns/auth/api/rolestatus?rtn_prd=${p}`); if (!ok(r)) throw fail(r, R); return push('status', r.json.data || r.json); } },
    { id: 'gstr1', label: 'GSTR-1 summary + B2B invoices', host: R, run: async p => {
      const r = await get(R, `/returns/auth/api/gstr1/summary?rtn_prd=${p}`); if (!ok(r)) throw fail(r, R);
      const a = await push('gstr1', r.json);
      const b = await get(R, `/returns/auth/api/gstr1/invoice?rtn_prd=${p}&sec_name=B2B&uploaded_by=SU`);
      if (ok(b)) { const x = await push('gstr1_b2b', b.json.data || b.json); return a + ' · ' + x; }
      return a; } },
    { id: 'gstr3b', label: 'GSTR-3B (as on portal)', host: R, run: async p => { const r = await get(R, `/returns/auth/api/gstr3b/summary?rtn_prd=${p}`); if (!ok(r)) throw fail(r, R); return push('gstr3b', r.json); } },
    { id: 'gstr2b', label: 'GSTR-2B (all documents)', host: B, run: async p => {
      const r = await get(B, `/gstr2b/auth/api/gstr2b/getdata?rtnprd=${p}`); if (!ok(r)) throw fail(r, B);
      let j = r.json, d = j.data && (j.data.data || j.data);
      if (d && !d.docdata && (d.fc || d.fileCount)) { // big 2B comes in parts
        const n = +(d.fc || d.fileCount), all = {};
        for (let i = 1; i <= n; i++) { const x = await get(B, `/gstr2b/auth/api/gstr2b/getdata?rtnprd=${p}&fn=${i}`); const xd = x.json && x.json.data && (x.json.data.data || x.json.data);
          if (!xd || !xd.docdata) throw 'This 2B is very large — download the 2B JSON from the portal and upload it in the tracker';
          for (const k in xd.docdata) all[k] = (all[k] || []).concat(xd.docdata[k]); d = { ...xd, docdata: all }; }
        j = { data: d };
      }
      return push('gstr2b', j); } },
    { id: 'gstr2a', label: 'GSTR-2A (B2B + credit notes)', host: R, run: async p => {
      const r = await get(R, `/returns/auth/api/gstr2a/b2b?rtn_prd=${p}`); if (!ok(r)) throw fail(r, R);
      const c = await get(R, `/returns/auth/api/gstr2a/cdn?rtn_prd=${p}`);
      const b2b = (r.json.data && r.json.data.b2b) || r.json.b2b || [], cdn = ok(c) ? ((c.json.data && c.json.data.cdn) || c.json.cdn || []) : [];
      return push('gstr2a', { b2b, cdn }); } },
    { id: 'pdfs', label: 'GSTR-1 / GSTR-3B PDFs (draft or filed)', host: R, run: async () => {
      const r = await send({ type: 'autopdf', gstin: st.gstin, month: st.month, force: true }); if (r.error) throw r.error;
      const c = await send({ type: 'cfg' });
      return [(r.got || []).length ? (r.got || []).join(', ') + ' kept' : 'nothing new', ...(r.note || []), c.waiting ? `${c.waiting} waiting — open the tracker to save` : 'saved in the tracker'].join(' · '); } },
    { id: 'info', label: 'Ledgers, TDS / TCS credit, LUT, applications, certificates, GSTR-9 figures', host: R, run: async () => {
      const { data, r } = await sendInfo(st.gstin); if (r.error) throw r.error;
      const n = x => (+x || 0).toLocaleString('en-IN'), c = data.credit || {}, k = data.cash || {};
      return [`credit ledger ₹${n(c.op_tot)}`, `cash ledger ₹${n(k.tot_rng_bal)}`, `${Object.values(data.cases || {}).reduce((a, x) => a + x.list.length, 0)} applications`, data.errors.length ? `${data.errors.length} not read` : '', r.trackerOpen ? 'saved in the tracker' : 'open the tracker to save'].filter(Boolean).join(' · '); } },
    { id: 'notices', label: 'Notices & orders (new ones are added)', host: S, run: async () => {
      const r = await get(S, '/services/auth/api/get/notices', { method: 'POST', body: { onLoad: true } });
      const list = r && r.json ? (Array.isArray(r.json) ? r.json : (r.json.data || [])) : null; if (!Array.isArray(list)) throw fail(r, S);
      const t = await send({ type: 'tracker', body: { action: 'notices', gstin: st.gstin, items: list } }); if (t.error) throw t.error;
      return `${list.length} on portal · ${t.added} new added`; } }
  ];
  async function push(kind, data) {
    const t = await send({ type: 'tracker', body: { action: 'push', gstin: st.gstin, month: st.month, kind, data } });
    if (t.error) throw t.error; return t.info || 'saved';
  }

  // ---------- panel ----------
  const st = { gstin: null, month: '', client: null, open: false, busy: false };
  const months = () => { const L = [], d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - 1);
    for (let i = 0; i < 14; i++) { L.push([`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`, `${MN[d.getMonth()]} ${d.getFullYear()}`]); d.setMonth(d.getMonth() - 1); } return L; };
  const rtnPrd = m => m.slice(5, 7) + m.slice(0, 4);
  let btn, box;
  function mount() {
    if (btn) return;
    btn = document.createElement('button'); btn.className = 'jlrg-fab'; btn.type = 'button'; btn.title = 'JLR GST Helper — send this client\'s data to the tracker'; btn.textContent = 'JLR';
    box = document.createElement('div'); box.className = 'jlrg-box'; box.hidden = true;
    document.body.append(btn, box);
    btn.onclick = () => { st.open = !st.open; box.hidden = !st.open; if (st.open) draw(); };
  }
  async function draw() {
    const c = await send({ type: 'cfg' });
    st.month = st.month || months()[0][0];
    const head = `<div class="jlrg-h"><b>JLR GST Helper</b><button type="button" class="jlrg-x" data-x aria-label="Close">×</button></div>`;
    if (!c.hasKey) { box.innerHTML = head + `<p>Add your tracker key first: click the <b>JLR</b> add-on icon in the Chrome toolbar (puzzle piece → JLR GST Helper).</p>`; return; }
    if (!st.client) { box.innerHTML = head + '<p class="jlrg-m">Finding this client in the tracker…</p>';
      const m = await send({ type: 'tracker', body: { action: 'match', gstins: [st.gstin] } }); st.client = m.error ? { error: m.error } : (m.clients || [])[0] || { error: 'Not found' }; }
    const cl = st.client;
    box.innerHTML = head + `<div class="jlrg-c">${esc(st.gstin)}<br>${cl.error ? `<span class="jlrg-bad">${esc(cl.error)}</span>` : `<b>${esc(cl.name)}</b>${cl.code ? ` · ${esc(cl.code)}` : ''}`}</div>
      ${cl.error ? '' : `<label class="jlrg-l">Return month <select data-mon>${months().map(([v, l]) => `<option value="${v}" ${v === st.month ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
      <div class="jlrg-steps">${STEPS.map(s => `<label><input type="checkbox" data-s="${s.id}" checked> ${esc(s.label)}</label>`).join('')}</div>
      <div data-filebox></div><div data-applybox></div>
      <button type="button" class="jlrg-go" data-go>Send to tracker</button>
      <div class="jlrg-log" data-log></div>
      <div class="jlrg-up" data-upbox></div>
      <p class="jlrg-note">Reads what the portal shows you. Uploads only after your click; filing, payment and EVC are always done by you.</p>`}
      <div class="jlrg-foot">Logged in to the tracker as ${esc(c.name || 'you')}</div>`;
    if (!cl.error) { loadUpload(); drawFileJobs(); drawApplyJobs(); }
  }

  // ---------- v1.6.0: File on portal — a job sent from the tracker; the add-on opens the return, checks the figures and stops at EVC ----------
  const GS = { busy: false, last: '', compared: '' };
  const MONTHS_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const vis = el => !!(el && el.offsetParent);
  const btnBy = (txt, attr) => [...document.querySelectorAll('button,a,input[type=button],input[type=submit]')].find(b => vis(b) && (attr ? new RegExp(attr).test(b.getAttribute('data-ng-click') || b.getAttribute('ng-click') || '') : new RegExp(txt, 'i').test((b.textContent || b.value || '').replace(/\s+/g, ' ').trim())));
  let gBox;
  function guideBox(h) {
    if (!gBox) { gBox = document.createElement('div'); gBox.className = 'jlrg-guide'; document.body.append(gBox);
      gBox.addEventListener('click', async e => {
        if (e.target.closest('[data-gstop]')) { await send({ type: 'guide_set', guide: null }); clearHl(); gBox.remove(); gBox = null; }
        if (e.target.closest('[data-gany]')) { const g = (await send({ type: 'guide_get' })).guide; if (g) { g.override = true; await send({ type: 'guide_set', guide: g }); } GS.compared = ''; }
      }); }
    gBox.innerHTML = `<div class="jlrg-h"><b>JLR · filing guide</b><button type="button" class="jlrg-x" data-gstop aria-label="Stop the guide">×</button></div>${h}`;
  }
  const clearHl = () => document.querySelectorAll('.jlrg-hl').forEach(x => x.classList.remove('jlrg-hl'));
  const hl = el => { if (el && !el.classList.contains('jlrg-hl')) { clearHl(); el.classList.add('jlrg-hl'); el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } };
  const r0 = v => Math.round(+v || 0), inr = v => '₹' + r0(v).toLocaleString('en-IN');
  async function compare(job) {
    const prd = rtnPrd(job.month);
    if (job.kind === 'gstr3b') {
      const b = await get(R, `/returns/auth/api/gstr3b/summary?rtn_prd=${prd}`), d = b && b.json && (b.json.data || b.json);
      if (!d || !d.sup_details) return { error: 'Could not read GSTR-3B from the portal' };
      const o = d.sup_details.osup_det || {}, n = (d.itc_elg || {}).itc_net || {}, E = (job.expect && job.expect.t3b) || {}, a = E.a || {}, c = E.C || {}, rows = [];
      [['3.1(a) taxable', o.txval, a.t], ['3.1(a) IGST', o.iamt, a.ig], ['3.1(a) CGST', o.camt, a.cg], ['3.1(a) SGST', o.samt, a.sg], ['4(C) IGST', n.iamt, c.ig], ['4(C) CGST', n.camt, c.cg], ['4(C) SGST', n.samt, c.sg]]
        .forEach(([l, p, t]) => rows.push({ l, p: r0(p), t: r0(t), ok: Math.abs(r0(p) - r0(t)) <= 1 }));
      return { rows, ok: rows.every(r => r.ok) };
    }
    const b = await get(R, `/returns/auth/api/gstr1/summary?rtn_prd=${prd}`), d = b && b.json && (b.json.data || b.json);
    if (!d || !Array.isArray(d.sec_sum)) return { error: 'Could not read the GSTR-1 summary from the portal — generate the summary first' };
    let val = 0, tax = 0;
    const ADD = ['B2B', 'B2CL', 'B2CS', 'EXP', 'AT', 'SEZWP', 'SEZWOP', 'DE'], SUB = ['CDNR', 'CDNUR', 'TXPD', 'ATADJ'];
    d.sec_sum.forEach(s => { const nm = String(s.sec_nm || '').toUpperCase(), k = ADD.includes(nm) ? 1 : SUB.includes(nm) ? -1 : 0; if (!k) return;
      val += k * (+(s.ttl_tax ?? s.ttl_txval) || 0); tax += k * ((+s.ttl_igst || 0) + (+s.ttl_cgst || 0) + (+s.ttl_sgst || 0) + (+s.ttl_cess || 0)); });
    const E = job.expect || {}, rows = [{ l: 'Taxable value', p: r0(val), t: r0(E.sales), ok: Math.abs(r0(val) - r0(E.sales)) <= 10 }, { l: 'Tax', p: r0(tax), t: r0(E.outTax), ok: Math.abs(r0(tax) - r0(E.outTax)) <= 10 }];
    return { rows, ok: rows.every(r => r.ok), approx: true };
  }
  const cmpHtml = c => c.error ? `<p class="jlrg-bad">${esc(c.error)}</p><button type="button" class="jlrg-go jlrg-ghost" data-gany>Continue without the check</button>` : `<table class="jlrg-t"><tr><th></th><th>Portal</th><th>Tracker</th></tr>${c.rows.map(r => `<tr class="${r.ok ? '' : 'jlrg-badrow'}"><td>${esc(r.l)}</td><td>${inr(r.p)}</td><td>${inr(r.t)}</td></tr>`).join('')}</table>
    ${c.ok ? '<p class="jlrg-ok">Portal figures match the verified workings ✓</p>' : `<p class="jlrg-bad">The portal does not match the verified workings${c.approx ? ' (GSTR-1 totals are compared roughly — check the summary)' : ''}. Check before filing.</p><button type="button" class="jlrg-go jlrg-ghost" data-gany>I have checked — continue</button>`}`;
  async function guideTick() {
    if (GS.busy || location.hostname !== R) return;
    const g = (await send({ type: 'guide_get' })).guide; if (!g) { if (gBox) { gBox.remove(); gBox = null; clearHl(); } return; }
    GS.busy = true;
    try {
      const j = g.job, K = j.kind === 'gstr3b' ? 'GSTR-3B' : 'GSTR-1', mon = `${MN[+j.month.slice(5) - 1]} ${j.month.slice(0, 4)}`, path = location.pathname, T = document.body.innerText || '';
      const steps = j.kind === 'gstr3b' ? ['Open GSTR-3B', 'Check figures', 'Proceed to payment (you)', 'Offset / pay (you)', 'File with EVC (you)'] : ['Open GSTR-1', 'Check figures', 'Summary → file page', 'Declaration + EVC (you)'];
      const stepHtml = n => `<ol class="jlrg-ol">${steps.map((s, i) => `<li class="${i < n ? 'done' : i === n ? 'now' : ''}">${esc(s)}</li>`).join('')}</ol>`;
      const head = `<div class="jlrg-c"><b>${esc(j.client || j.gstin)}</b><br>${K} · ${mon}</div>`;
      // filed?
      const okm = T.match(/successfully filed[\s\S]{0,200}?Acknowledg(?:e)?ment Reference Number\s*(?:\(ARN\))?\s*is\s*:?\s*([A-Z0-9]{12,18})/i);
      if (okm) { await send({ type: 'file_done', id: j.id, arn: okm[1] }); await send({ type: 'guide_set', guide: null }); clearHl();
        guideBox(head + `<p class="jlrg-ok">Filed ✓ · ARN ${esc(okm[1])}</p><p class="jlrg-m">The filed PDF and ARN go to the tracker in a minute (keep the tracker open in another tab).</p>`); return; }
      if (st.gstin && st.gstin !== j.gstin) { guideBox(head + `<p class="jlrg-bad">This portal login is ${esc(st.gstin)}, not ${esc(j.gstin)}. Log in to the right client.</p>`); return; }
      if (/\/returns\/auth\/dashboard$/.test(path)) {
        if (g.step !== 'dash') { g.step = 'dash'; await send({ type: 'guide_set', guide: g }); }
        guideBox(head + stepHtml(0) + '<p class="jlrg-m"><span class="jlrg-sp"></span> Opening the return…</p>');
        const y = +j.month.slice(0, 4), mo = +j.month.slice(5, 7), fs = mo >= 4 ? y : y - 1, fy = `${fs}-${String(fs + 1).slice(2)}`;
        const q = mo <= 3 ? 'Quarter 4 (Jan - Mar)' : mo <= 6 ? 'Quarter 1 (Apr - Jun)' : mo <= 9 ? 'Quarter 2 (Jul - Sep)' : 'Quarter 3 (Oct - Dec)';
        const S = n => document.querySelector(`select[name=${n}]`), set = (sel, txt) => { const o = sel && [...sel.options].find(o => o.text.trim() === txt); if (!o) return false; sel.value = o.value; sel.dispatchEvent(new Event('change', { bubbles: true })); return true; };
        if (!S('mon')) return;
        if (GS.last !== 'picked' + j.id) { set(S('fin'), fy); await wait(600); set(S('quarter'), q); await wait(700); if (!set(S('mon'), MONTHS_FULL[mo - 1])) { guideBox(head + `<p class="jlrg-bad">${mon} is not offered on the portal.</p>`); return; }
          await wait(400); const sb2 = btnBy('^search$'); if (sb2) sb2.click(); GS.last = 'picked' + j.id; await wait(3000); }
        const tileName = x => { let p = x; for (let i = 0; i < 8 && p; i++, p = p.parentElement) { const L = (p.innerText || '').split('\n').map(s => s.trim()).find(s => /^GSTR-\w+$/.test(s)); if (L) return L; } return ''; };
        const b = [...document.querySelectorAll('button')].find(x => vis(x) && /page_rtp/.test(x.getAttribute('data-ng-click') || '') && tileName(x) === K);
        if (!b) { guideBox(head + stepHtml(0) + `<p class="jlrg-bad">${K} for ${mon} is not on the dashboard${j.kind === 'gstr3b' ? ' yet' : ''}.</p>`); return; }
        if (new RegExp('\\n' + K + '\\s*\\n+\\s*Status\\s*-\\s*Filed', 'i').test(document.body.innerText || '')) { guideBox(head + `<p class="jlrg-ok">${K} ${mon} is already filed on the portal.</p>`); await send({ type: 'file_done', id: j.id }); await send({ type: 'guide_set', guide: null }); return; }
        g.step = 'form'; await send({ type: 'guide_set', guide: g }); GS.compared = ''; b.click(); return;
      }
      // file page (GSTR-1 file.html / GSTR-3B file section): declaration, signatory, EVC — the person does these
      const evc = btnBy('', 'fileWithEvc') || btnBy('file .*with evc');
      if (evc) { const cb = [...document.querySelectorAll('input[type=checkbox]')].find(vis), sel = [...document.querySelectorAll('select')].find(vis);
        const n = j.kind === 'gstr3b' ? 4 : 3; hl(cb && !cb.checked ? cb : sel && !sel.value ? sel : evc);
        guideBox(head + stepHtml(n) + `<p><b>Your turn:</b> tick the declaration, choose the authorised signatory, then <b>File with EVC</b> and type the OTP sent to the signatory. The add-on does not do these.</p>`); return; }
      if (j.kind === 'gstr1' && /\/returns\/auth\/gstr1(\/gstr1sum)?$/.test(path)) {
        if (GS.compared !== j.id) { guideBox(head + stepHtml(1) + '<p class="jlrg-m"><span class="jlrg-sp"></span> Reading the portal summary…</p>'); g.cmp = await compare(j); GS.compared = j.id; await send({ type: 'guide_set', guide: g }); }
        const c = g.cmp || {}, go = c.ok || g.override;
        if (/gstr1sum$/.test(path)) { const f = btnBy('', 'prepareForFile');
          guideBox(head + stepHtml(go ? 2 : 1) + cmpHtml(c) + (go && f ? '<p class="jlrg-m">Opening the file page…</p>' : ''));
          if (go && f && GS.last !== 'file' + j.id) { GS.last = 'file' + j.id; f.click(); } else if (f) hl(f); return; }
        const pv = btnBy('(view summary|proceed to file)'), gen = btnBy('', "checkForHsnRec\\('PTF'\\)");
        if (c.error && !g.override && gen && !pv && GS.last !== 'gen' + j.id) {        // no summary on the portal yet: ask the portal to make it, then read again
          GS.last = 'gen' + j.id; gen.click(); guideBox(head + stepHtml(1) + '<p class="jlrg-m"><span class="jlrg-sp"></span> Asked the portal to generate the GSTR-1 summary — reading it again in a few seconds…</p>');
          setTimeout(() => { GS.compared = ''; }, 12000); return; }
        guideBox(head + stepHtml(1) + cmpHtml(c) + (go ? '<p class="jlrg-m">Going to the summary…</p>' : ''));
        if (go) { if (pv && GS.last !== 'sum' + j.id) { GS.last = 'sum' + j.id; pv.click(); } else if (!pv && gen && GS.last !== 'gen' + j.id) { GS.last = 'gen' + j.id; gen.click(); } }
        return;
      }
      if (j.kind === 'gstr3b' && /\/returns\/auth\/gstr3b/.test(path)) {
        const close = btnBy('^close$'); if (close) close.click();
        if (GS.compared !== j.id) { guideBox(head + stepHtml(1) + '<p class="jlrg-m"><span class="jlrg-sp"></span> Reading GSTR-3B from the portal…</p>'); g.cmp = await compare(j); GS.compared = j.id; await send({ type: 'guide_set', guide: g }); }
        const c = g.cmp || {}, go = c.ok || g.override;
        const pay = btnBy('(make payment|post credit to ledger|offset liabilit)'), toPay = btnBy('^proceed to payment$'), toFile = btnBy('^proceed to file$');
        let tip = '', n = 1, el = null;
        if (!go) tip = '';
        else if (toFile) { n = 4; el = toFile; tip = 'Payment / offset is done. Click <b>Proceed to file</b>.'; }
        else if (pay) { n = 3; el = pay; tip = `Check the offset on screen${j.expect && j.expect.cash ? ` (tracker cash to pay ${inr(j.expect.cash)})` : ''}, then click <b>${esc((pay.textContent || '').trim())}</b>. This posts the credit / cash to the ledger — only you can do it.`; }
        else if (toPay) { n = 2; el = toPay; tip = 'Figures checked. Click <b>Proceed to payment</b>.'; }
        hl(el); guideBox(head + stepHtml(n) + cmpHtml(c) + (tip ? `<p><b>Your turn:</b> ${tip}</p>` : '')); return;
      }
      guideBox(head + '<p class="jlrg-m">Go to <b>Returns → Returns dashboard</b> and the guide will continue.</p>');
    } finally { GS.busy = false; }
  }
  setInterval(guideTick, 1800);
  async function drawFileJobs() {
    const el = box && box.querySelector('[data-filebox]'); if (!el) return;
    const r = await send({ type: 'file_list', gstin: st.gstin }), J = r.jobs || [];
    el.innerHTML = J.length ? J.map(j => `<div class="jlrg-c jlrg-file"><b>File ${j.kind === 'gstr3b' ? 'GSTR-3B' : 'GSTR-1'} · ${MN[+j.month.slice(5) - 1]} ${j.month.slice(0, 4)}</b><br><span class="jlrg-m">Sent from the tracker${j.by ? ' by ' + esc(j.by) : ''}</span>
      <div style="display:flex;gap:8px;margin-top:6px"><button type="button" class="jlrg-go" data-fstart="${esc(j.id)}">Start filing</button><button type="button" class="jlrg-go jlrg-ghost" data-fdel="${esc(j.id)}">Remove</button></div></div>`).join('') : '';
  }
  document.addEventListener('click', async e => {
    const s = e.target.closest && e.target.closest('[data-fstart]'); if (s && box && box.contains(s)) {
      const r = await send({ type: 'file_list', gstin: st.gstin }), j = (r.jobs || []).find(x => x.id === s.dataset.fstart); if (!j) return;
      await send({ type: 'guide_set', guide: { job: j, step: 'dash', at: Date.now() } }); GS.last = ''; GS.compared = '';
      st.open = false; box.hidden = true;
      if (location.hostname === R && /\/returns\/auth\/dashboard$/.test(location.pathname)) guideTick();
      else if (location.hostname === R) location.href = '/returns/auth/dashboard';
      else { const a = [...document.querySelectorAll('a')].find(x => /return\.gst\.gov\.in\/returns\/auth\/dashboard/.test(x.href)); if (a) a.click(); else location.href = 'https://return.gst.gov.in/returns/auth/dashboard'; }
      return; }
    const d = e.target.closest && e.target.closest('[data-fdel]'); if (d && box && box.contains(d)) { await send({ type: 'file_del', id: d.dataset.fdel }); drawFileJobs(); }
  });


  // ---------- v1.8.0 (stage 3): applications from the tracker — LUT is filled; other forms open with the tracker's notes. Never submits or signs. ----------
  const APPURL = { 'RFD-11': 'https://services.gst.gov.in/services2/auth/getlutform', 'REG-14 non-core': 'https://reg.gst.gov.in/registration/auth/amend/noncore/business',
    'REG-14 core': 'https://reg.gst.gov.in/registration/auth/amend/core/amendbusinessdetail', 'REG-04': 'https://reg.gst.gov.in/registration/auth/clarifications',
    'CMP-02': 'https://reg.gst.gov.in/registration/auth/optcomp', 'CMP-04': 'https://reg.gst.gov.in/registration/auth/wtdrwcomp', 'REG-16': 'https://reg.gst.gov.in/registration/auth/common/cancellation',
    'REG-21': 'https://reg.gst.gov.in/registration/auth/revoke', 'Geocoding': 'https://reg.gst.gov.in/registration/auth/geocode', 'Rule 14B': 'https://reg.gst.gov.in/registration/auth/rule14bPbiInitiation/business',
    'Specified premises': 'https://reg.gst.gov.in/registration/auth/specifiedpremises', 'REG-01': 'https://reg.gst.gov.in/registration/msr', 'Other': 'https://services.gst.gov.in/services/auth/dashboard',
    // v2.0.0 stage 5: other returns and forms
    'GSTR-2X': 'https://return.gst.gov.in/returns2/auth/comptds', 'RFD-01': 'https://refund.gst.gov.in/refunds/auth/refunddashboard', 'RFD-01W': 'https://refund.gst.gov.in/refunds/auth/savedapplication',
    'DRC-03': 'https://services.gst.gov.in/litserv/auth/case/search', 'DRC-03A': 'https://services.gst.gov.in/litserv/auth/case/search', 'PMT-09': 'https://payment.gst.gov.in/payment/auth/ledger/cashledger',
    'GSTP': 'https://services.gst.gov.in/services/auth/engdisenggstp', 'GTA': 'https://services.gst.gov.in/services/auth/gta' };
  ['GSTR-1A', 'IFF', 'CMP-08', 'GSTR-4', 'GSTR-7', 'GSTR-8', 'GSTR-10', 'GSTR-11', 'ITC-01', 'ITC-02', 'ITC-03', 'ITC-04', 'DRC-01B', 'DRC-01C'].forEach(f => { APPURL[f] = 'https://return.gst.gov.in/returns/auth/dashboard'; });
  const APPHINT = { 'GSTR-1A': 'Pick the month and open the GSTR-1A tile.', IFF: 'Pick the quarter and month, then open the IFF tile.', 'CMP-08': 'Pick the quarter and open the CMP-08 tile.', 'GSTR-4': 'Pick the financial year and open the GSTR-4 tile (Annual Return).',
    'GSTR-7': 'Pick the month and open the GSTR-7 tile.', 'GSTR-8': 'Pick the month and open the GSTR-8 tile.', 'GSTR-10': 'Open Services → Returns → Final Return.', 'GSTR-11': 'Pick the period and open the GSTR-11 tile.',
    'ITC-01': 'Open Services → Returns → ITC Forms → ITC-01.', 'ITC-02': 'Open Services → Returns → ITC Forms → ITC-02.', 'ITC-03': 'Open Services → Returns → ITC Forms → ITC-03.', 'ITC-04': 'Open Services → Returns → ITC Forms → ITC-04.',
    'DRC-01B': 'Open the DRC-01B intimation from the dashboard alert, or Services → Returns → Liability mismatch.', 'DRC-01C': 'Open the DRC-01C intimation from the dashboard alert.', 'GSTR-2X': 'Pick the year and month, then accept / reject each TDS / TCS entry.',
    'RFD-01': 'Choose the refund type and the period.', 'DRC-03': 'New application → Intimation of voluntary payment (DRC-03).', 'DRC-03A': 'New application → DRC-03A (link payment to demand).', 'PMT-09': 'Use “File GST PMT-09” on this page.' };
  const AG = { busy: false, nav: '' };
  let aBox;
  function aguideBox(h) {
    if (!aBox) { aBox = document.createElement('div'); aBox.className = 'jlrg-guide'; document.body.append(aBox);
      aBox.addEventListener('click', async e => { if (e.target.closest('[data-astop]')) { await send({ type: 'aguide_set', guide: null }); clearHl(); aBox.remove(); aBox = null; }
        if (e.target.closest('[data-arefill]')) { const g = (await send({ type: 'aguide_get' })).guide; if (g) { g.filled = false; await send({ type: 'aguide_set', guide: g }); } } }); }
    aBox.innerHTML = `<div class="jlrg-h"><b>JLR · application guide</b><button type="button" class="jlrg-x" data-astop aria-label="Stop the guide">×</button></div>${h}`;
  }
  const aSetVal = (el, v) => { if (!el || v === undefined || v === null || v === '') return false; el.focus(); el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); el.blur(); return true; };
  const setSel = (el, txt) => { if (!el || !txt) return false; const t = String(txt).trim().toLowerCase(), o = [...el.options].find(o => o.text.trim().toLowerCase() === t) || [...el.options].find(o => o.text.trim().toLowerCase().includes(t));
    if (!o) return false; el.value = o.value; el.dispatchEvent(new Event('change', { bubbles: true })); return true; };
  const byName = n => document.querySelector(`[name="${n}"]`);
  async function fillLut(d, fy) {
    const miss = [];
    if (!setSel(byName('fyear'), fy)) miss.push('financial year ' + fy);
    const W = [[d.w1 || {}, ['name', 'ocp1', 'build1', 'floor', 'prem', 'road1', 'city1', 'applnState', 'applnDistr', 'pin1']], [d.w2 || {}, ['name2', 'occ2', 'build2', 'floor2', 'prem2', 'street', 'city2', 'state2', 'dist2', 'pin2']]];
    for (const [w, n] of W) {
      [['name', 0], ['occupation', 1], ['buildno', 2], ['floorno', 3], ['buildname', 4], ['street', 5], ['city', 6]].forEach(([k, i]) => { if (w[k]) aSetVal(byName(n[i]), w[k]); });
      if (w.state) { if (setSel(byName(n[7]), w.state)) { const dEl = byName(n[8]); for (let i = 0; i < 12 && dEl && dEl.options.length < 2; i++) await wait(500); if (w.dist && !setSel(dEl, w.dist)) miss.push(`district “${w.dist}” for ${w.name}`); } else miss.push(`state for ${w.name}`); }
      if (w.pincode) aSetVal(byName(n[9]), w.pincode);
    }
    if (d.place) aSetVal(byName('placeoffile'), d.place);
    if (d.signatory && !setSel(byName('signatory'), d.signatory)) miss.push(`signatory “${d.signatory}”`);
    if (d.signPlace) aSetVal(byName('placee'), d.signPlace);
    return miss;
  }
  async function aguideTick() {
    if (AG.busy) return;
    const g = (await send({ type: 'aguide_get' })).guide; if (!g) { if (aBox) { aBox.remove(); aBox = null; } return; }
    AG.busy = true;
    try {
      const j = g.job, url = APPURL[j.form] || APPURL.Other, u = new URL(url), here = location.hostname === u.hostname && location.pathname.startsWith(u.pathname);
      const head = `<div class="jlrg-c"><b>${esc(j.client || j.gstin)}</b><br>${esc(j.form)}${j.fy ? ' · FY ' + esc(j.fy) : ''}</div>`;
      const T = document.body.innerText || '', am = T.match(/(?:submitted|filed)\s+successfully[\s\S]{0,250}?\b(A[A-Z]\d{2}\d{4}\d{6,8}[A-Z0-9])\b/i) || T.match(/\bARN\b[^A-Z0-9]{0,30}(A[A-Z]\d{12,14}[A-Z0-9])/);
      if ((here || g.arrived) && am && /success/i.test(T)) { await send({ type: 'apply_done', id: j.id, arn: am[1] }); await send({ type: 'aguide_set', guide: null }); clearHl();
        aguideBox(head + `<p class="jlrg-ok">Submitted ✓ · ARN ${esc(am[1])}</p><p class="jlrg-m">Saved to the tracker (keep it open in another tab). The officer's decision is read with the daily portal check.</p>`); return; }
      if (st.gstin && st.gstin !== j.gstin) { aguideBox(head + `<p class="jlrg-bad">This portal login is ${esc(st.gstin)}, not ${esc(j.gstin)}.</p>`); return; }
      if (here && !g.arrived) { g.arrived = true; await send({ type: 'aguide_set', guide: g }); }
      if (!here && !g.arrived) { aguideBox(head + '<p class="jlrg-m"><span class="jlrg-sp"></span> Opening the form on the portal…</p>'); if (AG.nav !== j.id + location.href) { AG.nav = j.id + location.href; location.href = url; } return; }
      if (j.form === 'RFD-11' && here) {
        if (!byName('fyear')) { aguideBox(head + '<p class="jlrg-m"><span class="jlrg-sp"></span> Waiting for the LUT form…</p>'); return; }
        if (!g.filled) { aguideBox(head + '<p class="jlrg-m"><span class="jlrg-sp"></span> Filling the LUT from the tracker…</p>'); g.miss = await fillLut(j.details || {}, j.fy); g.filled = true; await send({ type: 'aguide_set', guide: g }); }
        const decl = ['chck1', 'chck2', 'chck3'].map(byName).filter(Boolean), open = decl.find(x => !x.checked);
        hl(open || document.querySelector('[ng-click*="openPdf"],[data-ng-click*="openPdf"]') || null);
        aguideBox(head + `<p class="jlrg-ok">Filled from the tracker: year, both witnesses, places${(j.details || {}).signatory ? ', signatory' : ''}.</p>
          ${(g.miss || []).length ? `<p class="jlrg-bad">Could not fill: ${esc(g.miss.join(', '))} — pick them on the form.</p>` : ''}
          <p><b>Your turn:</b> read and tick the ${decl.length || 3} declarations${open ? ' (highlighted)' : ' ✓'}, check every field, attach the previous LUT if asked, <b>SAVE</b> / <b>PREVIEW</b>, then <b>SIGN and FILE</b> with DSC or EVC. The add-on does not tick declarations or sign.</p>
          <button type="button" class="jlrg-go jlrg-ghost" data-arefill>Fill again from the tracker</button>`);
        return;
      }
      aguideBox(head + `${APPHINT[j.form] ? `<p><b>Where:</b> ${esc(APPHINT[j.form])}</p>` : ''}<p class="jlrg-m">${j.fy ? `Period / year: <b>${esc(j.fy)}</b>. ` : ''}Fill it on the portal. Notes from the tracker:</p><div class="jlrg-c" style="white-space:pre-wrap">${esc(j.notes || '—')}</div>
        <p class="jlrg-m">Submit / sign as usual. When the portal shows the ARN, the add-on saves it to the tracker.</p>`);
    } finally { AG.busy = false; }
  }
  setInterval(aguideTick, 1800);
  async function drawApplyJobs() {
    const el = box && box.querySelector('[data-applybox]'); if (!el) return;
    const r = await send({ type: 'apply_list', gstin: st.gstin }), J = r.jobs || [];
    el.innerHTML = J.map(j => `<div class="jlrg-c jlrg-file"><b>${j.form === 'RFD-11' ? 'Fill' : 'Open'} ${esc(j.form)}${j.fy ? ' · FY ' + esc(j.fy) : ''}</b><br><span class="jlrg-m">Sent from the tracker${j.by ? ' by ' + esc(j.by) : ''}</span>
      <div style="display:flex;gap:8px;margin-top:6px"><button type="button" class="jlrg-go" data-astart="${esc(j.id)}">Start</button><button type="button" class="jlrg-go jlrg-ghost" data-adel="${esc(j.id)}">Remove</button></div></div>`).join('');
  }
  document.addEventListener('click', async e => {
    const s = e.target.closest && e.target.closest('[data-astart]'); if (s && box && box.contains(s)) {
      const r = await send({ type: 'apply_list', gstin: st.gstin }), j = (r.jobs || []).find(x => x.id === s.dataset.astart); if (!j) return;
      await send({ type: 'aguide_set', guide: { job: j, at: Date.now() } }); AG.nav = ''; st.open = false; box.hidden = true; aguideTick(); return; }
    const d = e.target.closest && e.target.closest('[data-adel]'); if (d && box && box.contains(d)) { await send({ type: 'apply_del', id: d.dataset.adel }); drawApplyJobs(); }
  });

  // ---------- v59: GSTR-1 JSON upload (made in the tracker → uploaded here after a staff click) ----------
  const UP = { job: null, confirm: false, busy: false };
  const statusOf = raw => {      // read the portal's offline-upload summary: P = processed, PE = processed with errors, ER = error, IP = in progress
    const vals = []; const walk = (o, k) => { if (o && typeof o === 'object') Object.entries(o).forEach(([kk, v]) => walk(v, kk)); else if (typeof o === 'string' && /st|status/i.test(k || '')) vals.push(o.trim()); }; walk(raw);
    if (vals.some(v => /^(PE|Processed with Error.*)$/i.test(v))) return 'error';
    if (vals.some(v => /^(ER|Error.*|Failed)$/i.test(v))) return 'error';
    if (vals.some(v => /^(P|Processed)$/i.test(v))) return 'processed';
    return 'pending';
  };
  const KL = { gstr1: 'GSTR-1', gstr3b: 'GSTR-3B' };
  async function loadUpload(note, noteKind) {
    const box = box_(); if (!box) return;
    const [y, m] = st.month.split('-'), mon = `${MN[+m - 1]} ${y}`, H = [];
    UP.jobs = UP.jobs || {};
    for (const kind of ['gstr1', 'gstr3b']) {
      const t = await send({ type: 'tracker', body: { action: 'upload_get', gstin: st.gstin, month: st.month, kind } });
      if (t.error) { if (!/not set up/.test(t.error) && kind === 'gstr1') H.push(`<p class="jlrg-m">${esc(t.error)}</p>`); continue; }
      const j = UP.jobs[kind] = t.job; if (!j) continue;
      const done = j.status === 'processed', K = KL[kind];
      H.push(`<div class="jlrg-c"><b>${K} upload · ${mon}</b><br><span class="jlrg-m">${esc(j.info || '')}${j.by ? ' · sent by ' + esc(j.by) : ''}</span>
        <br><span class="${done ? 'jlrg-ok' : j.status === 'error' ? 'jlrg-bad' : 'jlrg-m'}">${({ ready: 'Ready to upload', uploading: 'Uploading…', processed: 'Uploaded and processed on the portal ✓', error: 'Last upload had errors', pending: 'Uploaded — the portal is still processing' })[j.status] || esc(j.status)}${j.message ? ' — ' + esc(j.message) : ''}</span></div>
        ${note && noteKind === kind ? `<p class="jlrg-m">${note}</p>` : ''}
        ${done ? '' : UP.confirm === kind ? `<p class="jlrg-bad" style="margin:6px 0">${kind === 'gstr3b' ? `This replaces the GSTR-3B figures saved on the portal for <b>${esc((st.client || {}).name || st.gstin)}</b>, <b>${mon}</b> (tables 3.1 and 4 from the tracker; 3.2, 5 and interest stay as on the portal). It does not offset, pay or file.` : `This adds the invoices to the GSTR-1 draft of <b>${esc((st.client || {}).name || st.gstin)}</b> for <b>${mon}</b> on the portal. It does not submit or file.`}</p>
            <div style="display:flex;gap:8px"><button type="button" class="jlrg-go" data-upyes="${kind}">Yes, upload</button><button type="button" class="jlrg-go jlrg-ghost" data-upno>Cancel</button></div>`
          : `<button type="button" class="jlrg-go" data-upgo="${kind}" ${j.json ? '' : 'disabled'}>Upload ${K} to portal</button>`}`);
    }
    box.innerHTML = H.length ? H.join('') : `<p class="jlrg-m">Nothing waiting to upload for ${mon}. In the tracker: GSTR-1 step 4 → “Send JSON to JLR add-on”, GSTR-3B step 5 → “Send 3B to JLR add-on”.</p>`;
  }
  const box_ = () => box && box.querySelector('[data-upbox]');
  const near = (a, b) => Math.abs((+a || 0) - (+b || 0)) <= 1;
  async function doUpload(kind) {
    const j = (UP.jobs || {})[kind]; if (!j || !j.json || UP.busy) return; UP.busy = true; UP.confirm = false;
    const [y, m] = st.month.split('-'), prd = m + y, el = box_(), K = KL[kind];
    const say = h => { if (el) el.innerHTML = `<div class="jlrg-c">${h}</div>`; };
    const report = (status, message, result) => send({ type: 'tracker', body: { action: 'upload_report', gstin: st.gstin, month: st.month, kind, id: j.id, status, message, result } });
    say(`<span class="jlrg-sp"></span> Uploading ${K} to the portal…`);
    await report('uploading');
    const r = await send({ type: 'upload', kind, payload: j.json, rtnPrd: prd, fname: `${kind === 'gstr3b' ? 'GSTR3B' : 'GSTR1'}_${st.gstin}_${prd}.json`, gstin: st.gstin });
    if (!r || !r.ok) {
      const msg = r && r.error === 'not-json' ? 'The portal did not answer — if it logged you out, log in again and retry' : (r && r.error) || 'Upload failed';
      await report('error', msg, r && r.raw || null); UP.busy = false; loadUpload(`<span class="jlrg-bad">${esc(msg)}</span>`, kind); return;
    }
    say(`<span class="jlrg-sp"></span> Uploaded — waiting for the portal to process ${K} (this can take a few minutes)…`);
    let state = 'pending', raw = null;
    for (let i = 0; i < 30; i++) {
      await new Promise(res => setTimeout(res, i < 6 ? 5000 : 10000));
      const s2 = await get(R, `/returns/auth/api/offline/upload/summary?rtn_prd=${prd}&rtn_typ=${kind === 'gstr3b' ? 'GSTR3B' : 'GSTR1'}`);
      if (s2 && s2.json && String(s2.json.status) === '1') { raw = s2.json.data || s2.json; state = statusOf(raw); if (state !== 'pending') break; }
    }
    let msg = state === 'processed' ? 'Processed on the portal' : state === 'error' ? 'The portal found errors — open Prepare offline → Upload and download the error report' : 'Still processing — check Prepare offline → Upload later';
    if (kind === 'gstr3b' && state === 'processed') {      // read the 3B back and compare with what we sent
      const b = await get(R, `/returns/auth/api/gstr3b/summary?rtn_prd=${prd}`), d = b && b.json && (b.json.data || b.json), F = (j.json && j.json.figs) || {};
      if (d && d.sup_details) {
        const o = d.sup_details.osup_det || {}, n = (d.itc_elg || {}).itc_net || {}, a = F.a || {}, c = F.C || {}, bad = [];
        [['txval', 't'], ['iamt', 'ig'], ['camt', 'cg'], ['samt', 'sg']].forEach(([pk, tk]) => { if (!near(o[pk], a[tk])) bad.push(`3.1(a) ${pk} portal ${o[pk] || 0} vs ${a[tk] || 0}`); });
        [['iamt', 'ig'], ['camt', 'cg'], ['samt', 'sg']].forEach(([pk, tk]) => { if (!near(n[pk], c[tk])) bad.push(`4(C) ${pk} portal ${n[pk] || 0} vs ${c[tk] || 0}`); });
        msg = bad.length ? 'Processed, but the portal shows different figures: ' + bad.join('; ') : 'Processed — portal 3.1(a) and 4(C) match the tracker ✓';
      }
    }
    await report(state, msg, raw); UP.busy = false;
    loadUpload(state === 'processed' ? `<span class="jlrg-ok">${esc(msg)}${kind === 'gstr1' ? ' — check the GSTR-1 summary on the portal against the tracker (step 3) before filing.' : ' — now offset and file on the portal.'}</span>` : '', kind);
  }
  document.addEventListener('click', async e => {
    if (!box || !box.contains(e.target)) return;
    if (e.target.closest('[data-x]')) { st.open = false; box.hidden = true; return; }
    const ug = e.target.closest('[data-upgo]'); if (ug) { UP.confirm = ug.dataset.upgo; loadUpload(); return; }
    if (e.target.closest('[data-upno]')) { UP.confirm = false; loadUpload(); return; }
    const uy = e.target.closest('[data-upyes]'); if (uy) { doUpload(uy.dataset.upyes); return; }
    const go = e.target.closest('[data-go]'); if (!go || st.busy) return;
    st.busy = true; go.disabled = true; go.textContent = 'Sending…';
    st.month = box.querySelector('[data-mon]').value; const p = rtnPrd(st.month);
    const log = box.querySelector('[data-log]'); log.innerHTML = '';
    const on = new Set([...box.querySelectorAll('[data-s]:checked')].map(i => i.dataset.s));
    let good = 0, bad = 0;
    for (const s of STEPS.filter(x => on.has(x.id))) {
      const row = document.createElement('div'); row.innerHTML = `<span class="jlrg-sp"></span> ${esc(s.label.split(' (')[0])}…`; log.append(row);
      try { const msg = await s.run(p); row.innerHTML = `<span class="jlrg-ok">✓</span> ${esc(s.label.split(' (')[0])} — ${esc(msg)}`; good++; }
      catch (err) { row.innerHTML = `<span class="jlrg-bad">✗</span> ${esc(s.label.split(' (')[0])} — ${esc(String(err && err.message || err))}`; bad++; }
    }
    const end = document.createElement('div'); end.className = 'jlrg-end';
    end.textContent = bad ? `${good} sent, ${bad} not sent.` : `All sent. Open GST review in the tracker to use it.`; log.append(end);
    st.busy = false; go.disabled = false; go.textContent = 'Send again';
  });
  document.addEventListener('change', e => { if (box && e.target.matches && e.target.matches('[data-mon]')) { st.month = e.target.value; UP.confirm = false; loadUpload(); } });

  // ---------- GSTIN check (Search Taxpayer page) ----------
  // The tracker opens .../services/searchtp#jlrg=GSTIN (one) or #jlrq=G1,G2,... (a list).
  // We fill the GSTIN; the staff member types the captcha and searches. In list mode the result is saved
  // by itself and the next GSTIN comes up — staff only type captchas. The add-on never fills the captcha.
  const Q = {
    get() { try { return JSON.parse(sessionStorage.getItem('jlrg_q') || 'null'); } catch { return null; } },
    set(q) { try { q ? sessionStorage.setItem('jlrg_q', JSON.stringify(q)) : sessionStorage.removeItem('jlrg_q'); } catch { /* ignore */ } }
  };
  const takeHash = () => {
    const one = (location.hash.match(/jlrg=([0-9A-Z]{15})/) || [])[1];
    const many = (location.hash.match(/jlrq=([0-9A-Z,]+)/) || [])[1];
    if (!one && !many) return;
    try {
      if (many) { const L = [...new Set(many.split(',').filter(g => GSTIN_RE.test(g)))]; Q.set({ list: L, i: 0, saved: 0, skipped: 0 }); sessionStorage.removeItem('jlrg_want'); }
      else { sessionStorage.setItem('jlrg_want', one); Q.set(null); }
      history.replaceState(null, '', location.pathname + location.search);
    } catch { /* ignore */ }
    filledFor = ''; lastKey = '';
    if (chk) chk.hidden = true;
  };
  window.addEventListener('hashchange', takeHash);
  const wanted = () => { const q = Q.get(); return q && q.i < q.list.length ? q.list[q.i] : sessionStorage.getItem('jlrg_want'); };
  let filledFor = '';
  function fillSearch() {
    const g = wanted(); if (!g || !/searchtp/.test(location.pathname) || filledFor === g + location.href) return;
    const ins = [...document.querySelectorAll('input')];
    const inp = ins.find(i => /gstin/i.test((i.placeholder || '') + (i.name || '') + (i.id || '')));
    if (!inp) return;
    if (inp.value !== g) { inp.value = g; inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true })); inp.dispatchEvent(new Event('blur', { bubbles: true })); }
    filledFor = g + location.href;
    // the portal shows the captcha box after the GSTIN is entered — put the cursor there for the staff member
    setTimeout(() => { const cap = [...document.querySelectorAll('input')].find(i => /character|captcha/i.test((i.placeholder || '') + (i.name || '') + (i.id || ''))); if (cap) cap.focus(); }, 600);
  }
  const LABELS = { legal_name: /^Legal Name of Business/i, trade_name: /^Trade Name/i, reg_date: /^Effective Date of registration/i, status: /^GSTIN \/ UIN Status|^GSTIN\/UIN Status/i,
    taxpayer_type: /^Taxpayer Type/i, cancel_date: /^Effective Date of Cancellation/i, constitution: /^Constitution of Business/i, jurisdiction: /^Administrative Office|^Other Office/i };
  function readResult() {
    if (!/searchtp/.test(location.pathname)) return null;
    const lines = (document.body.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
    const gi = lines.findIndex(l => /^GSTIN\/UIN\s*:?/i.test(l) && GSTIN_RE.test(l)); const res = {};
    for (const [k, re] of Object.entries(LABELS)) { const i = lines.findIndex(l => re.test(l)); if (i >= 0) { const same = lines[i].replace(re, '').replace(/^[\s:]+/, ''); res[k] = same || lines[i + 1] || ''; } }
    if (!res.legal_name || !res.status) return null;
    const g = gi >= 0 ? lines[gi].match(GSTIN_RE)[0] : (wanted() || ([...document.querySelectorAll('input')].map(i => i.value).find(v => GSTIN_RE.test(v)) || ''));
    return g ? { gstin: g, ...res } : null;
  }
  let chk, lastKey = '', saving = false;
  const chkBox = () => { if (!chk) { chk = document.createElement('div'); chk.className = 'jlrg-chk'; document.body.append(chk); } chk.hidden = false; return chk; };
  async function save(r) {
    const { gstin, ...rest } = r;
    return send({ type: 'tracker', body: { action: 'check', gstin, result: { ...rest, detail: rest } } });
  }
  function nextInQueue(how) {
    const q = Q.get(); if (!q) return;
    q.i++; if (how === 'saved') q.saved++; else q.skipped++; Q.set(q);
    filledFor = '';
    if (q.i >= q.list.length) { drawQueue(); return; }
    setTimeout(() => { location.href = location.origin + '/services/searchtp'; }, 900);   // fresh search form for the next GSTIN
  }
  function drawQueue(note) {
    const q = Q.get(); if (!q || !/searchtp/.test(location.pathname)) return;
    const box = chkBox(), done = q.i >= q.list.length;
    box.innerHTML = `<b>GSTIN check list</b> · ${Math.min(q.i + (done ? 0 : 1), q.list.length)} of ${q.list.length}
      <div class="jlrg-m">${q.saved} saved${q.skipped ? ` · ${q.skipped} skipped` : ''}</div>
      ${done ? '<p class="jlrg-ok">All done — open GSTIN check in the tracker to see the results.</p><div><button type="button" data-qend>Close</button></div>'
        : `<p>Now: <b>${esc(q.list[q.i])}</b><br><span class="jlrg-m">Type the captcha and press Enter — the result is saved by itself.</span></p>${note ? `<p>${note}</p>` : ''}
           <div><button type="button" data-qskip class="jlrg-ghost">Skip</button><button type="button" data-qstop class="jlrg-ghost">Stop list</button></div>`}`;
    const b = s => box.querySelector(s);
    if (b('[data-qskip]')) b('[data-qskip]').onclick = () => nextInQueue('skipped');
    if (b('[data-qstop]')) b('[data-qstop]').onclick = () => { Q.set(null); box.hidden = true; };
    if (b('[data-qend]')) b('[data-qend]').onclick = () => { Q.set(null); box.hidden = true; };
  }
  function offerCheck() {
    const r = readResult(), q = Q.get(), key = r ? r.gstin + r.status + r.legal_name : '';
    if (q) {                                                   // list mode
      if (q.i >= q.list.length) { if (!chk || chk.hidden || !/All done/.test(chk.textContent)) drawQueue(); return; }
      if (!r) { if (key !== lastKey || !chk || chk.hidden) { lastKey = key; drawQueue(); } return; }
      if (key === lastKey || saving) return; lastKey = key;
      if (q.i < q.list.length && r.gstin !== q.list[q.i]) { drawQueue(`<span class="jlrg-bad">The result is for ${esc(r.gstin)}, not the GSTIN in the list — search again, or Skip.</span>`); return; }
      saving = true; drawQueue('Saving…');
      save(r).then(t => { saving = false;
        if (t.error) { drawQueue(`<span class="jlrg-bad">${esc(t.error)}</span>`); lastKey = ''; return; }
        drawQueue(`<span class="jlrg-ok">${esc(r.gstin)}: ${esc(r.status)} — saved ✓</span>`); nextInQueue('saved'); });
      return;
    }
    if (!r) { if (chk) chk.hidden = true; return; }
    if (key === lastKey && chk && !chk.hidden) return; lastKey = key;
    const box = chkBox();
    box.innerHTML = `<b>${esc(r.gstin)}</b> · ${esc(r.legal_name)}<br>Status: <b class="${/active/i.test(r.status) ? 'jlrg-ok' : 'jlrg-bad'}">${esc(r.status)}</b>
      <div><button type="button" data-save>Save GSTIN check to tracker</button><button type="button" data-close class="jlrg-ghost">Hide</button></div><div data-cm class="jlrg-m"></div>`;
    box.querySelector('[data-close]').onclick = () => { box.hidden = true; };
    box.querySelector('[data-save]').onclick = async ev => {
      ev.target.disabled = true;
      const t = await save(r);
      box.querySelector('[data-cm]').innerHTML = t.error ? `<span class="jlrg-bad">${esc(t.error)}</span>` : '<span class="jlrg-ok">Saved in the tracker ✓</span>';
      if (!t.error) sessionStorage.removeItem('jlrg_want'); ev.target.disabled = false;
    };
  }

  // ---------- v58 quick login: tracker opens .../services/login#jlrt=<one-time ticket> ----------
  // The add-on trades the ticket for the saved login (same staff member, once, 2 minutes), fills username + password,
  // and shows a popup with the captcha picture. The staff member types the captcha; the add-on never reads or solves it.
  const QL = { box: null, client: '', tries: 0 };
  const setVal = (el, v) => { const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value'); d.set.call(el, v);
    ['input', 'change', 'keyup', 'blur'].forEach(t => el.dispatchEvent(new Event(t, { bubbles: true }))); };
  const qlFind = () => {
    const vis = i => i.offsetParent !== null && i.type !== 'hidden' && getComputedStyle(i).visibility !== 'hidden';
    const all = [...document.querySelectorAll('input')], ins = all.filter(vis);
    const pass = ins.find(i => i.type === 'password') || all.find(i => i.type === 'password');   // the GST login page has a hidden second password box
    const user = ins.find(i => i !== pass && /user/i.test((i.id || '') + (i.name || '') + (i.placeholder || ''))) || ins.find(i => i !== pass && i.type === 'text');
    const cap = ins.find(i => /captcha|character/i.test((i.id || '') + (i.name || '') + (i.placeholder || '')));
    const img = [...document.querySelectorAll('img')].find(m => /captcha/i.test((m.id || '') + (m.src || '') + (m.alt || '')) && m.offsetParent !== null);
    const btn = [...document.querySelectorAll('button, input[type=submit]')].find(b => /^\s*log\s*in\s*$/i.test(b.textContent || b.value || '') && b.offsetParent !== null);
    return { user, pass, cap, img, btn };
  };
  function qlBox() {
    if (!QL.box) { QL.box = document.createElement('div'); QL.box.className = 'jlrg-ql'; QL.box.setAttribute('role', 'dialog'); QL.box.setAttribute('aria-label', 'JLR quick login'); document.body.append(QL.box); }
    return QL.box;
  }
  function qlDraw(msg) {
    const f = qlFind(), box = qlBox();
    box.innerHTML = `<div class="jlrg-h"><b>JLR quick login</b><button type="button" class="jlrg-x" data-qlx aria-label="Close">×</button></div>
      <div class="jlrg-c">${esc(QL.client)}<br><span class="jlrg-m">Username and password are filled in. Type the captcha below.</span></div>
      ${f.img ? '<canvas data-qlimg width="200" height="60" aria-label="Captcha picture from the GST portal"></canvas>' : '<p class="jlrg-m">Captcha picture not shown yet…</p>'}
      ${f.cap ? `<input data-qlcap autocomplete="off" spellcheck="false" placeholder="Type the characters" aria-label="Captcha">` : ''}
      <div style="display:flex;gap:8px">${f.img ? '<button type="button" class="jlrg-ghost" data-qlnew>New picture</button>' : ''}<button type="button" data-qlgo>Log in</button></div>
      ${msg ? `<p class="${/wrong|invalid|error|not/i.test(msg) ? 'jlrg-bad' : 'jlrg-m'}">${esc(msg)}</p>` : ''}`;
    const cv = box.querySelector('[data-qlimg]');
    if (cv && f.img) { const paint = () => { try { const w = f.img.naturalWidth || 200, h = f.img.naturalHeight || 60, k = Math.min(2.2, 260 / w); cv.width = w * k; cv.height = h * k; const g = cv.getContext('2d'); g.imageSmoothingEnabled = false; g.drawImage(f.img, 0, 0, w * k, h * k); } catch { /* ignore */ } };
      if (f.img.complete) paint(); else f.img.addEventListener('load', paint, { once: true }); QL.src = f.img.src; }
    const ci = box.querySelector('[data-qlcap]'); if (ci) { ci.focus(); ci.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); qlGo(); } }; }
    box.querySelector('[data-qlx]').onclick = () => { box.remove(); QL.box = null; QL.on = false; };
    const nb = box.querySelector('[data-qlnew]'); if (nb) nb.onclick = () => { const r = f.img && (f.img.parentElement.querySelector('[class*=refresh], [title*=efresh], [aria-label*=efresh], [ng-click*=efresh]') || document.querySelector('[class*=refresh][ng-click], .fa-refresh'));
      if (r) { r.click(); setTimeout(() => qlDraw(), 900); } else qlDraw('Click the refresh icon next to the captcha on the page'); };
    box.querySelector('[data-qlgo]').onclick = () => qlGo();
  }
  function qlGo() {
    const f = qlFind(), ci = QL.box && QL.box.querySelector('[data-qlcap]');
    if (f.cap && ci) { const v = ci.value.trim(); if (!v) { qlDraw('Type the captcha first'); return; } setVal(f.cap, v); }
    if (!f.btn) { qlDraw('Press LOGIN on the page'); return; }
    QL.tries++; f.btn.click();
    setTimeout(() => { if (/services\/login/.test(location.pathname) && QL.on) qlDraw('If the portal says the captcha is wrong, type the new one'); }, 2500);
  }
  async function quickLogin(ticket) {
    QL.on = true; qlBox().innerHTML = '<div class="jlrg-h"><b>JLR quick login</b></div><p class="jlrg-m">Getting the saved login from the tracker…</p>';
    const t = await send({ type: 'tracker', body: { action: 'login', ticket } });
    if (t.error || !t.login) { qlBox().innerHTML = `<div class="jlrg-h"><b>JLR quick login</b><button type="button" class="jlrg-x" data-qlx aria-label="Close">×</button></div><p class="jlrg-bad">${esc(t.error || 'No login')}</p>`; QL.box.querySelector('[data-qlx]').onclick = () => { QL.box.remove(); QL.box = null; }; QL.on = false; return; }
    QL.client = `${t.client || ''}${t.gstin ? ' · ' + t.gstin : ''}`;
    let pw = t.password; t.password = null;
    for (let i = 0; i < 40; i++) { const f = qlFind(); if (f.user && f.pass) { setVal(f.user, t.login); if (pw) setVal(f.pass, pw); pw = null; break; } await new Promise(r => setTimeout(r, 250)); }
    pw = null;
    for (let i = 0; i < 24 && !qlFind().cap; i++) await new Promise(r => setTimeout(r, 250));   // the portal may show the captcha only after the username is in
    qlDraw();
  }
  (() => { const m = location.hash.match(/jlrt=(jlrt_[0-9a-f]{48})/); if (!m) return;
    try { history.replaceState(null, '', location.pathname + location.search); } catch { /* ignore */ }
    if (/services\/login/.test(location.pathname)) setTimeout(() => quickLogin(m[1]), 600); })();
  // keep the captcha picture in the popup fresh when the portal changes it (wrong captcha → new picture)
  setInterval(() => { if (!QL.on || !QL.box || !/services\/login/.test(location.pathname)) return; const f = qlFind(); if (f.img && f.img.src !== QL.src) qlDraw(); }, 1200);

  takeHash();

  // ---------- v1.5.0: PDFs the portal makes (hook.js) → tracker ----------
  let toastEl;
  const toast = (h, bad) => { if (!toastEl) { toastEl = document.createElement('div'); toastEl.className = 'jlrg-toast'; document.body.append(toastEl); } toastEl.innerHTML = h; toastEl.className = 'jlrg-toast' + (bad ? ' bad' : ''); toastEl.hidden = false; clearTimeout(toastEl.t); toastEl.t = setTimeout(() => { toastEl.hidden = true; }, 6000); };
  window.addEventListener('message', async e => {
    if (e.source !== window || !e.data || e.data.__jlrpdf !== 1) return;
    const { name, b64, wm, texts } = e.data;
    const r = await send({ type: 'pdf', name, b64, wm, texts });
    if (r.error) return;
    toast(`<b>JLR</b> · ${r.kind === 'gstr3b' ? 'GSTR-3B' : 'GSTR-1'} ${r.stage === 'filed' ? 'filed' : 'draft'} PDF kept for the tracker${r.trackerOpen ? '' : ' — <a href="#" data-opentr>open the tracker</a> to save it'}`);
    const a = toastEl.querySelector('[data-opentr]'); if (a) a.onclick = ev => { ev.preventDefault(); send({ type: 'openTracker' }); };
  });
  const autoDone = new Set();
  async function autoPdfs(g) {
    if (location.hostname !== R && location.hostname !== S) return;
    const m = months()[0][0], key = g + '|' + m; if (autoDone.has(key)) return; autoDone.add(key);
    const c = await send({ type: 'cfg' }); if (!c.hasKey || !c.autoPdf) return;
    await new Promise(res => setTimeout(res, 4000));                    // let the portal finish loading first
    send({ type: 'want_run', gstin: g });
    send({ type: 'info_due', gstin: g }).then(d => { if (d && d.due) sendInfo(g).catch(() => {}); });
    const r = await send({ type: 'autopdf', gstin: g, month: m });
    if (r && r.ok && (r.got || []).length) toast(`<b>JLR</b> · ${esc((r.got || []).join(', '))} PDF kept for the tracker (${MN[+m.slice(5) - 1]} ${m.slice(0, 4)})`);
  }

  // ---------- watch the page (the portal draws pages after load) ----------
  let tick = 0;
  const loop = () => {
    const g = loggedGstin();
    if (g) { if (g !== st.gstin) { st.gstin = g; st.client = null; } mount(); btn.hidden = false; if (window.top === window) autoPdfs(g); }
    else if (btn) { btn.hidden = true; box.hidden = true; st.open = false; }
    fillSearch(); offerCheck();
    tick++; setTimeout(loop, tick < 20 ? 1000 : 2500);
  };
  loop();
})();
