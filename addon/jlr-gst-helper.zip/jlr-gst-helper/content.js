// JLR GST Helper — runs on the GST portal pages.
// After the staff member logs in (password + captcha typed by them), a "JLR" button appears.
// It reads only what the portal already shows to the logged-in taxpayer and sends it to the tracker.
// It never files, submits, saves or changes anything on the portal, and never touches the login details.
(() => {
  if (window.__jlrg) return; window.__jlrg = true;
  const R = 'return.gst.gov.in', S = 'services.gst.gov.in', B = 'gstr2b.gst.gov.in';
  const GSTIN_RE = /\b[0-9]{2}[A-Z0-9]{10}[0-9A-Z]Z[0-9A-Z]\b/;
  const MN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const send = msg => new Promise(res => { try { chrome.runtime.sendMessage(msg, r => res(r || { error: chrome.runtime.lastError ? 'The add-on was updated — reload this page' : 'No answer' })); } catch { res({ error: 'The add-on was updated — reload this page' }); } });

  // ---------- who is logged in ----------
  function loggedGstin() {
    const out = [...document.querySelectorAll('a')].find(a => /^\s*logout\s*$/i.test(a.textContent || ''));
    if (!out) return null;
    let el = out; for (let i = 0; i < 8 && el; i++, el = el.parentElement) { const m = (el.textContent || '').match(GSTIN_RE); if (m) return m[0]; }
    const head = document.querySelector('header, .navbar, .top-header') || document.body; const m = (head.innerText || '').slice(0, 3000).match(GSTIN_RE);
    return m ? m[0] : null;
  }

  // ---------- reading the portal ----------
  async function get(host, path, opt = {}) {
    const url = `https://${host}${path}`;
    if (host === location.hostname) {
      try {
        const r = await fetch(path, { method: opt.method || 'GET', credentials: 'include', headers: opt.body ? { 'content-type': 'application/json' } : {}, body: opt.body ? JSON.stringify(opt.body) : undefined });
        const t = await r.text(); try { return { status: r.status, json: JSON.parse(t) }; } catch { return { status: r.status, error: 'not-json' }; }
      } catch { return { error: 'network' }; }
    }
    return send({ type: 'portal', url, method: opt.method, body: opt.body });
  }
  const hostName = h => ({ [R]: 'Returns', [S]: 'Dashboard', [B]: 'GSTR-2B' }[h]);
  function fail(r, host) {
    if (r && r.json && r.json.error) return (r.json.error.message || r.json.error.errorCode || 'Portal error') + '';
    if (r && r.error === 'not-json') return `The portal did not give data — if the portal logged you out, log in again; otherwise open the ${hostName(host)} page once from the portal menu and press Send again`;
    return (r && r.error) || 'Portal did not answer';
  }
  const ok = r => r && r.json && !r.json.error && (r.json.status === undefined || r.json.status === 1 || r.json.status === 200 || r.json.data);

  const STEPS = [
    { id: 'status', label: 'Return status (filed / not filed)', host: R, run: async p => { const r = await get(R, `/returns/auth/api/rolestatus?rtn_prd=${p}`); if (!ok(r)) throw fail(r, R); return push('status', r.json.data || r.json); } },
    { id: 'gstr1', label: 'GSTR-1 summary + B2B invoices', host: R, run: async p => {
      const r = await get(R, `/returns/auth/api/gstr1/summary?rtn_prd=${p}`); if (!ok(r)) throw fail(r, R);
      const a = await push('gstr1', r.json);
      const b = await get(R, `/returns/auth/api/gstr1/invoice?rtn_prd=${p}&sec_name=B2B&uploaded_by=SU`);
      if (ok(b)) { const x = await push('gstr1_b2b', b.json.data || b.json); return a + ' · ' + x; }
      return a; } },
    { id: 'gstr3b', label: 'GSTR-3B (as on portal)', host: R, run: async p => { const r = await get(R, `/returns/auth/api/gstr3b/summary?rtn_prd=${p}`); if (!ok(r)) throw fail(r, R); return push('gstr3b', r.json); } },
    { id: 'gstr2b', label: 'GSTR-2B (all documents)', host: B, run: async p => {
      const r = await get(B, `/gstr2b/auth/api/gstr2b/getdata?rtnprd=${p}`); if (!ok(r)) throw fail(r, B);
      let j = r.json, d = j.data && (j.data.data || j.data);
      if (d && !d.docdata && (d.fc || d.fileCount)) { // big 2B comes in parts
        const n = +(d.fc || d.fileCount), all = {};
        for (let i = 1; i <= n; i++) { const x = await get(B, `/gstr2b/auth/api/gstr2b/getdata?rtnprd=${p}&fn=${i}`); const xd = x.json && x.json.data && (x.json.data.data || x.json.data);
          if (!xd || !xd.docdata) throw 'This 2B is very large — download the 2B JSON from the portal and upload it in the tracker';
          for (const k in xd.docdata) all[k] = (all[k] || []).concat(xd.docdata[k]); d = { ...xd, docdata: all }; }
        j = { data: d };
      }
      return push('gstr2b', j); } },
    { id: 'gstr2a', label: 'GSTR-2A (B2B + credit notes)', host: R, run: async p => {
      const r = await get(R, `/returns/auth/api/gstr2a/b2b?rtn_prd=${p}`); if (!ok(r)) throw fail(r, R);
      const c = await get(R, `/returns/auth/api/gstr2a/cdn?rtn_prd=${p}`);
      const b2b = (r.json.data && r.json.data.b2b) || r.json.b2b || [], cdn = ok(c) ? ((c.json.data && c.json.data.cdn) || c.json.cdn || []) : [];
      return push('gstr2a', { b2b, cdn }); } },
    { id: 'notices', label: 'Notices & orders (new ones are added)', host: S, run: async () => {
      const r = await get(S, '/services/auth/api/get/notices', { method: 'POST', body: { onLoad: true } });
      const list = r && r.json ? (Array.isArray(r.json) ? r.json : (r.json.data || [])) : null; if (!Array.isArray(list)) throw fail(r, S);
      const t = await send({ type: 'tracker', body: { action: 'notices', gstin: st.gstin, items: list } }); if (t.error) throw t.error;
      return `${list.length} on portal · ${t.added} new added`; } }
  ];
  async function push(kind, data) {
    const t = await send({ type: 'tracker', body: { action: 'push', gstin: st.gstin, month: st.month, kind, data } });
    if (t.error) throw t.error; return t.info || 'saved';
  }

  // ---------- panel ----------
  const st = { gstin: null, month: '', client: null, open: false, busy: false };
  const months = () => { const L = [], d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - 1);
    for (let i = 0; i < 14; i++) { L.push([`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`, `${MN[d.getMonth()]} ${d.getFullYear()}`]); d.setMonth(d.getMonth() - 1); } return L; };
  const rtnPrd = m => m.slice(5, 7) + m.slice(0, 4);
  let btn, box;
  function mount() {
    if (btn) return;
    btn = document.createElement('button'); btn.className = 'jlrg-fab'; btn.type = 'button'; btn.title = 'JLR GST Helper — send this client\'s data to the tracker'; btn.textContent = 'JLR';
    box = document.createElement('div'); box.className = 'jlrg-box'; box.hidden = true;
    document.body.append(btn, box);
    btn.onclick = () => { st.open = !st.open; box.hidden = !st.open; if (st.open) draw(); };
  }
  async function draw() {
    const c = await send({ type: 'cfg' });
    st.month = st.month || months()[0][0];
    const head = `<div class="jlrg-h"><b>JLR GST Helper</b><button type="button" class="jlrg-x" data-x aria-label="Close">×</button></div>`;
    if (!c.hasKey) { box.innerHTML = head + `<p>Add your tracker key first: click the <b>JLR</b> add-on icon in the Chrome toolbar (puzzle piece → JLR GST Helper).</p>`; return; }
    if (!st.client) { box.innerHTML = head + '<p class="jlrg-m">Finding this client in the tracker…</p>';
      const m = await send({ type: 'tracker', body: { action: 'match', gstins: [st.gstin] } }); st.client = m.error ? { error: m.error } : (m.clients || [])[0] || { error: 'Not found' }; }
    const cl = st.client;
    box.innerHTML = head + `<div class="jlrg-c">${esc(st.gstin)}<br>${cl.error ? `<span class="jlrg-bad">${esc(cl.error)}</span>` : `<b>${esc(cl.name)}</b>${cl.code ? ` · ${esc(cl.code)}` : ''}`}</div>
      ${cl.error ? '' : `<label class="jlrg-l">Return month <select data-mon>${months().map(([v, l]) => `<option value="${v}" ${v === st.month ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
      <div class="jlrg-steps">${STEPS.map(s => `<label><input type="checkbox" data-s="${s.id}" checked> ${esc(s.label)}</label>`).join('')}</div>
      <button type="button" class="jlrg-go" data-go>Send to tracker</button>
      <div class="jlrg-log" data-log></div>
      <p class="jlrg-note">Only reads what the portal shows you. Nothing is filed or changed on the portal.</p>`}
      <div class="jlrg-foot">Logged in to the tracker as ${esc(c.name || 'you')}</div>`;
  }
  document.addEventListener('click', async e => {
    if (!box || !box.contains(e.target)) return;
    if (e.target.closest('[data-x]')) { st.open = false; box.hidden = true; return; }
    const go = e.target.closest('[data-go]'); if (!go || st.busy) return;
    st.busy = true; go.disabled = true; go.textContent = 'Sending…';
    st.month = box.querySelector('[data-mon]').value; const p = rtnPrd(st.month);
    const log = box.querySelector('[data-log]'); log.innerHTML = '';
    const on = new Set([...box.querySelectorAll('[data-s]:checked')].map(i => i.dataset.s));
    let good = 0, bad = 0;
    for (const s of STEPS.filter(x => on.has(x.id))) {
      const row = document.createElement('div'); row.innerHTML = `<span class="jlrg-sp"></span> ${esc(s.label.split(' (')[0])}…`; log.append(row);
      try { const msg = await s.run(p); row.innerHTML = `<span class="jlrg-ok">✓</span> ${esc(s.label.split(' (')[0])} — ${esc(msg)}`; good++; }
      catch (err) { row.innerHTML = `<span class="jlrg-bad">✗</span> ${esc(s.label.split(' (')[0])} — ${esc(String(err && err.message || err))}`; bad++; }
    }
    const end = document.createElement('div'); end.className = 'jlrg-end';
    end.textContent = bad ? `${good} sent, ${bad} not sent.` : `All sent. Open GST review in the tracker to use it.`; log.append(end);
    st.busy = false; go.disabled = false; go.textContent = 'Send again';
  });
  document.addEventListener('change', e => { if (box && e.target.matches && e.target.matches('[data-mon]')) st.month = e.target.value; });

  // ---------- GSTIN check (Search Taxpayer page) ----------
  // The tracker opens .../services/searchtp#jlrg=GSTIN (one) or #jlrq=G1,G2,... (a list).
  // We fill the GSTIN; the staff member types the captcha and searches. In list mode the result is saved
  // by itself and the next GSTIN comes up — staff only type captchas. The add-on never fills the captcha.
  const Q = {
    get() { try { return JSON.parse(sessionStorage.getItem('jlrg_q') || 'null'); } catch { return null; } },
    set(q) { try { q ? sessionStorage.setItem('jlrg_q', JSON.stringify(q)) : sessionStorage.removeItem('jlrg_q'); } catch { /* ignore */ } }
  };
  const takeHash = () => {
    const one = (location.hash.match(/jlrg=([0-9A-Z]{15})/) || [])[1];
    const many = (location.hash.match(/jlrq=([0-9A-Z,]+)/) || [])[1];
    if (!one && !many) return;
    try {
      if (many) { const L = [...new Set(many.split(',').filter(g => GSTIN_RE.test(g)))]; Q.set({ list: L, i: 0, saved: 0, skipped: 0 }); sessionStorage.removeItem('jlrg_want'); }
      else { sessionStorage.setItem('jlrg_want', one); Q.set(null); }
      history.replaceState(null, '', location.pathname + location.search);
    } catch { /* ignore */ }
    filledFor = ''; lastKey = '';
    if (chk) chk.hidden = true;
  };
  window.addEventListener('hashchange', takeHash);
  const wanted = () => { const q = Q.get(); return q && q.i < q.list.length ? q.list[q.i] : sessionStorage.getItem('jlrg_want'); };
  let filledFor = '';
  function fillSearch() {
    const g = wanted(); if (!g || !/searchtp/.test(location.pathname) || filledFor === g + location.href) return;
    const ins = [...document.querySelectorAll('input')];
    const inp = ins.find(i => /gstin/i.test((i.placeholder || '') + (i.name || '') + (i.id || '')));
    if (!inp) return;
    if (inp.value !== g) { inp.value = g; inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true })); inp.dispatchEvent(new Event('blur', { bubbles: true })); }
    filledFor = g + location.href;
    // the portal shows the captcha box after the GSTIN is entered — put the cursor there for the staff member
    setTimeout(() => { const cap = [...document.querySelectorAll('input')].find(i => /character|captcha/i.test((i.placeholder || '') + (i.name || '') + (i.id || ''))); if (cap) cap.focus(); }, 600);
  }
  const LABELS = { legal_name: /^Legal Name of Business/i, trade_name: /^Trade Name/i, reg_date: /^Effective Date of registration/i, status: /^GSTIN \/ UIN Status|^GSTIN\/UIN Status/i,
    taxpayer_type: /^Taxpayer Type/i, cancel_date: /^Effective Date of Cancellation/i, constitution: /^Constitution of Business/i, jurisdiction: /^Administrative Office|^Other Office/i };
  function readResult() {
    if (!/searchtp/.test(location.pathname)) return null;
    const lines = (document.body.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
    const gi = lines.findIndex(l => /^GSTIN\/UIN\s*:?/i.test(l) && GSTIN_RE.test(l)); const res = {};
    for (const [k, re] of Object.entries(LABELS)) { const i = lines.findIndex(l => re.test(l)); if (i >= 0) { const same = lines[i].replace(re, '').replace(/^[\s:]+/, ''); res[k] = same || lines[i + 1] || ''; } }
    if (!res.legal_name || !res.status) return null;
    const g = gi >= 0 ? lines[gi].match(GSTIN_RE)[0] : (wanted() || ([...document.querySelectorAll('input')].map(i => i.value).find(v => GSTIN_RE.test(v)) || ''));
    return g ? { gstin: g, ...res } : null;
  }
  let chk, lastKey = '', saving = false;
  const chkBox = () => { if (!chk) { chk = document.createElement('div'); chk.className = 'jlrg-chk'; document.body.append(chk); } chk.hidden = false; return chk; };
  async function save(r) {
    const { gstin, ...rest } = r;
    return send({ type: 'tracker', body: { action: 'check', gstin, result: { ...rest, detail: rest } } });
  }
  function nextInQueue(how) {
    const q = Q.get(); if (!q) return;
    q.i++; if (how === 'saved') q.saved++; else q.skipped++; Q.set(q);
    filledFor = '';
    if (q.i >= q.list.length) { drawQueue(); return; }
    setTimeout(() => { location.href = location.origin + '/services/searchtp'; }, 900);   // fresh search form for the next GSTIN
  }
  function drawQueue(note) {
    const q = Q.get(); if (!q || !/searchtp/.test(location.pathname)) return;
    const box = chkBox(), done = q.i >= q.list.length;
    box.innerHTML = `<b>GSTIN check list</b> · ${Math.min(q.i + (done ? 0 : 1), q.list.length)} of ${q.list.length}
      <div class="jlrg-m">${q.saved} saved${q.skipped ? ` · ${q.skipped} skipped` : ''}</div>
      ${done ? '<p class="jlrg-ok">All done — open GSTIN check in the tracker to see the results.</p><div><button type="button" data-qend>Close</button></div>'
        : `<p>Now: <b>${esc(q.list[q.i])}</b><br><span class="jlrg-m">Type the captcha and press Enter — the result is saved by itself.</span></p>${note ? `<p>${note}</p>` : ''}
           <div><button type="button" data-qskip class="jlrg-ghost">Skip</button><button type="button" data-qstop class="jlrg-ghost">Stop list</button></div>`}`;
    const b = s => box.querySelector(s);
    if (b('[data-qskip]')) b('[data-qskip]').onclick = () => nextInQueue('skipped');
    if (b('[data-qstop]')) b('[data-qstop]').onclick = () => { Q.set(null); box.hidden = true; };
    if (b('[data-qend]')) b('[data-qend]').onclick = () => { Q.set(null); box.hidden = true; };
  }
  function offerCheck() {
    const r = readResult(), q = Q.get(), key = r ? r.gstin + r.status + r.legal_name : '';
    if (q) {                                                   // list mode
      if (q.i >= q.list.length) { if (!chk || chk.hidden || !/All done/.test(chk.textContent)) drawQueue(); return; }
      if (!r) { if (key !== lastKey || !chk || chk.hidden) { lastKey = key; drawQueue(); } return; }
      if (key === lastKey || saving) return; lastKey = key;
      if (q.i < q.list.length && r.gstin !== q.list[q.i]) { drawQueue(`<span class="jlrg-bad">The result is for ${esc(r.gstin)}, not the GSTIN in the list — search again, or Skip.</span>`); return; }
      saving = true; drawQueue('Saving…');
      save(r).then(t => { saving = false;
        if (t.error) { drawQueue(`<span class="jlrg-bad">${esc(t.error)}</span>`); lastKey = ''; return; }
        drawQueue(`<span class="jlrg-ok">${esc(r.gstin)}: ${esc(r.status)} — saved ✓</span>`); nextInQueue('saved'); });
      return;
    }
    if (!r) { if (chk) chk.hidden = true; return; }
    if (key === lastKey && chk && !chk.hidden) return; lastKey = key;
    const box = chkBox();
    box.innerHTML = `<b>${esc(r.gstin)}</b> · ${esc(r.legal_name)}<br>Status: <b class="${/active/i.test(r.status) ? 'jlrg-ok' : 'jlrg-bad'}">${esc(r.status)}</b>
      <div><button type="button" data-save>Save GSTIN check to tracker</button><button type="button" data-close class="jlrg-ghost">Hide</button></div><div data-cm class="jlrg-m"></div>`;
    box.querySelector('[data-close]').onclick = () => { box.hidden = true; };
    box.querySelector('[data-save]').onclick = async ev => {
      ev.target.disabled = true;
      const t = await save(r);
      box.querySelector('[data-cm]').innerHTML = t.error ? `<span class="jlrg-bad">${esc(t.error)}</span>` : '<span class="jlrg-ok">Saved in the tracker ✓</span>';
      if (!t.error) sessionStorage.removeItem('jlrg_want'); ev.target.disabled = false;
    };
  }

  // ---------- v58 quick login: tracker opens .../services/login#jlrt=<one-time ticket> ----------
  // The add-on trades the ticket for the saved login (same staff member, once, 2 minutes), fills username + password,
  // and shows a popup with the captcha picture. The staff member types the captcha; the add-on never reads or solves it.
  const QL = { box: null, client: '', tries: 0 };
  const setVal = (el, v) => { const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value'); d.set.call(el, v);
    ['input', 'change', 'keyup', 'blur'].forEach(t => el.dispatchEvent(new Event(t, { bubbles: true }))); };
  const qlFind = () => {
    const ins = [...document.querySelectorAll('input')].filter(i => i.offsetParent !== null || i.type === 'password');
    const pass = ins.find(i => i.type === 'password');
    const user = ins.find(i => i !== pass && /user/i.test((i.id || '') + (i.name || '') + (i.placeholder || ''))) || ins.find(i => i !== pass && i.type === 'text');
    const cap = ins.find(i => /captcha|character/i.test((i.id || '') + (i.name || '') + (i.placeholder || '')));
    const img = [...document.querySelectorAll('img')].find(m => /captcha/i.test((m.id || '') + (m.src || '') + (m.alt || '')) && m.offsetParent !== null);
    const btn = [...document.querySelectorAll('button, input[type=submit]')].find(b => /^\s*log\s*in\s*$/i.test(b.textContent || b.value || '') && b.offsetParent !== null);
    return { user, pass, cap, img, btn };
  };
  function qlBox() {
    if (!QL.box) { QL.box = document.createElement('div'); QL.box.className = 'jlrg-ql'; QL.box.setAttribute('role', 'dialog'); QL.box.setAttribute('aria-label', 'JLR quick login'); document.body.append(QL.box); }
    return QL.box;
  }
  function qlDraw(msg) {
    const f = qlFind(), box = qlBox();
    box.innerHTML = `<div class="jlrg-h"><b>JLR quick login</b><button type="button" class="jlrg-x" data-qlx aria-label="Close">×</button></div>
      <div class="jlrg-c">${esc(QL.client)}<br><span class="jlrg-m">Username and password are filled in. Type the captcha below.</span></div>
      ${f.img ? '<canvas data-qlimg width="200" height="60" aria-label="Captcha picture from the GST portal"></canvas>' : '<p class="jlrg-m">Captcha picture not shown yet…</p>'}
      ${f.cap ? `<input data-qlcap autocomplete="off" spellcheck="false" placeholder="Type the characters" aria-label="Captcha">` : ''}
      <div style="display:flex;gap:8px">${f.img ? '<button type="button" class="jlrg-ghost" data-qlnew>New picture</button>' : ''}<button type="button" data-qlgo>Log in</button></div>
      ${msg ? `<p class="${/wrong|invalid|error|not/i.test(msg) ? 'jlrg-bad' : 'jlrg-m'}">${esc(msg)}</p>` : ''}`;
    const cv = box.querySelector('[data-qlimg]');
    if (cv && f.img) { const paint = () => { try { const w = f.img.naturalWidth || 200, h = f.img.naturalHeight || 60, k = Math.min(2.2, 260 / w); cv.width = w * k; cv.height = h * k; const g = cv.getContext('2d'); g.imageSmoothingEnabled = false; g.drawImage(f.img, 0, 0, w * k, h * k); } catch { /* ignore */ } };
      if (f.img.complete) paint(); else f.img.addEventListener('load', paint, { once: true }); QL.src = f.img.src; }
    const ci = box.querySelector('[data-qlcap]'); if (ci) { ci.focus(); ci.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); qlGo(); } }; }
    box.querySelector('[data-qlx]').onclick = () => { box.remove(); QL.box = null; QL.on = false; };
    const nb = box.querySelector('[data-qlnew]'); if (nb) nb.onclick = () => { const r = f.img && (f.img.parentElement.querySelector('[class*=refresh], [title*=efresh], [aria-label*=efresh], [ng-click*=efresh]') || document.querySelector('[class*=refresh][ng-click], .fa-refresh'));
      if (r) { r.click(); setTimeout(() => qlDraw(), 900); } else qlDraw('Click the refresh icon next to the captcha on the page'); };
    box.querySelector('[data-qlgo]').onclick = () => qlGo();
  }
  function qlGo() {
    const f = qlFind(), ci = QL.box && QL.box.querySelector('[data-qlcap]');
    if (f.cap && ci) { const v = ci.value.trim(); if (!v) { qlDraw('Type the captcha first'); return; } setVal(f.cap, v); }
    if (!f.btn) { qlDraw('Press LOGIN on the page'); return; }
    QL.tries++; f.btn.click();
    setTimeout(() => { if (/services\/login/.test(location.pathname) && QL.on) qlDraw('If the portal says the captcha is wrong, type the new one'); }, 2500);
  }
  async function quickLogin(ticket) {
    QL.on = true; qlBox().innerHTML = '<div class="jlrg-h"><b>JLR quick login</b></div><p class="jlrg-m">Getting the saved login from the tracker…</p>';
    const t = await send({ type: 'tracker', body: { action: 'login', ticket } });
    if (t.error || !t.login) { qlBox().innerHTML = `<div class="jlrg-h"><b>JLR quick login</b><button type="button" class="jlrg-x" data-qlx aria-label="Close">×</button></div><p class="jlrg-bad">${esc(t.error || 'No login')}</p>`; QL.box.querySelector('[data-qlx]').onclick = () => { QL.box.remove(); QL.box = null; }; QL.on = false; return; }
    QL.client = `${t.client || ''}${t.gstin ? ' · ' + t.gstin : ''}`;
    let pw = t.password; t.password = null;
    for (let i = 0; i < 40; i++) { const f = qlFind(); if (f.user && f.pass) { setVal(f.user, t.login); if (pw) setVal(f.pass, pw); pw = null; break; } await new Promise(r => setTimeout(r, 250)); }
    pw = null;
    for (let i = 0; i < 24 && !qlFind().cap; i++) await new Promise(r => setTimeout(r, 250));   // the portal may show the captcha only after the username is in
    qlDraw();
  }
  (() => { const m = location.hash.match(/jlrt=(jlrt_[0-9a-f]{48})/); if (!m) return;
    try { history.replaceState(null, '', location.pathname + location.search); } catch { /* ignore */ }
    if (/services\/login/.test(location.pathname)) setTimeout(() => quickLogin(m[1]), 600); })();
  // keep the captcha picture in the popup fresh when the portal changes it (wrong captcha → new picture)
  setInterval(() => { if (!QL.on || !QL.box || !/services\/login/.test(location.pathname)) return; const f = qlFind(); if (f.img && f.img.src !== QL.src) qlDraw(); }, 1200);

  takeHash();

  // ---------- watch the page (the portal draws pages after load) ----------
  let tick = 0;
  const loop = () => {
    const g = loggedGstin();
    if (g) { if (g !== st.gstin) { st.gstin = g; st.client = null; } mount(); btn.hidden = false; }
    else if (btn) { btn.hidden = true; box.hidden = true; st.open = false; }
    fillSearch(); offerCheck();
    tick++; setTimeout(loop, tick < 20 ? 1000 : 2500);
  };
  loop();
})();
