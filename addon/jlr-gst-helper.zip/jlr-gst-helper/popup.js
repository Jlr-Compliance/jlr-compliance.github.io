const $ = id => document.getElementById(id);
async function show() {
  const s = await chrome.storage.local.get(['key', 'name', 'server', 'tracker']);
  $('server').value = s.server || ''; $('tracker').value = s.tracker || '';
  $('setup').hidden = !!s.key; $('done').hidden = !s.key;
  $('state').innerHTML = s.key ? `<span class="ok">● Connected as ${(s.name || 'you').replace(/[<>&]/g, '')}</span>` : '<span class="bad">Not connected to the tracker yet</span>';
}
$('save').onclick = async () => {
  const k = $('key').value.trim();
  if (!/^jlrg_[0-9a-f]{48}$/.test(k)) { $('state').innerHTML = '<span class="bad">That is not an add-on key (it starts with jlrg_)</span>'; return; }
  await chrome.storage.local.set({ key: k });
  const r = await chrome.runtime.sendMessage({ type: 'tracker', body: { action: 'whoami' } });
  if (r && r.ok) { await chrome.storage.local.set({ name: r.name || '' }); show(); }
  else { await chrome.storage.local.remove('key'); $('state').innerHTML = `<span class="bad">${String((r && r.error) || 'Key not accepted').replace(/[<>&]/g, '')}</span>`; }
};
$('change').onclick = async () => { await chrome.storage.local.remove(['key', 'name']); show(); };
$('openT').onclick = async () => { const s = await chrome.storage.local.get('tracker'); chrome.tabs.create({ url: s.tracker || 'https://jlr-compliance.github.io/' }); };
$('saveAdv').onclick = async () => {
  const sv = $('server').value.trim().replace(/\/$/, ''), tr = $('tracker').value.trim();
  if (sv && !/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(sv)) { $('state').innerHTML = '<span class="bad">Server must look like https://xxxx.supabase.co</span>'; return; }
  await chrome.storage.local.set({ server: sv, tracker: tr }); show();
};
show();
