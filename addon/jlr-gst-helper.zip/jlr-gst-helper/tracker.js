// JLR GST Helper — runs on the tracker site. Hands GST PDFs taken from the portal to the tracker page (which saves them with the
// staff member's own login), and tells the add-on which ones were saved.
(() => {
  if (window.__jlrTr) return; window.__jlrTr = true;
  try { document.documentElement.dataset.jlrAddon = chrome.runtime.getManifest().version; } catch { /* ignore */ }
  const ask = msg => new Promise(res => { try { chrome.runtime.sendMessage(msg, r => res(r || {})); } catch { res({}); } });
  let busy = false;
  async function offer() {
    if (busy) return; const q = await ask({ type: 'pdfq_get' }); const items = q.items || [];
    if (!items.length) return; busy = true;
    window.postMessage({ __jlrq: 'pdfs', items }, location.origin);
    setTimeout(() => { busy = false; }, 60000);
  }
  window.addEventListener('message', async e => {
    if (e.source !== window || !e.data) return;
    if (e.data.__jlrq === 'ready') offer();
    if (e.data.__jlrq === 'file' && e.data.job) { await ask({ type: 'file_add', job: e.data.job }); return; }
    if (e.data.__jlrq === 'want' && e.data.items) { await ask({ type: 'want_add', items: e.data.items }); return; }
    if (e.data.__jlrq === 'pdfs-done') { busy = false; await ask({ type: 'pdfq_done', results: e.data.results || [] }); }
  });
  chrome.runtime.onMessage.addListener(m => { if (m && m.type === 'pdfq_new') offer(); });
  setInterval(offer, 45000);
})();
